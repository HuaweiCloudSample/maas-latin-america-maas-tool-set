# MaaS API Key Management Platform

一个极简可一键部署的 AI Token 管理平台。它把 PostgreSQL、Redis、LiteLLM、后端 API 和 Web 管理台打包到同一个 Docker 镜像里，并提供 Windows 双击启动脚本自动部署到华为云 ECS。

## 已实现能力

- Windows 双击 `Start-Deploy.cmd` 作为总入口
- PowerShell 状态提示和进度条
- 输入华为云临时 AK、SK、STS Security Token 后自动调用云 API
- 自动检测执行脚本电脑的公网 IP
- 自动创建 VPC、子网、安全组和 ECS
- ECS 安全组只放通当前公网 IP 的 TCP 80/8080
- 自动构建镜像并推送到华为云 SWR
- ECS 首次启动自动安装 Docker、拉取镜像并设置容器开机自启动
- Web 管理台支持公司、上游模型、Key 分组、虚拟 Key 管理
- 管理台会动态维护 LiteLLM Proxy 配置；新增或删除上游模型后自动重启 LiteLLM
- 分组支持日/月输入 token 和输出 token 总额度
- 虚拟 Key 支持自定义日/月输入输出额度；留空则按组剩余额度平均分配
- 组内所有自定义 Key 额度总和不能超过组总额度
- 后端网关只做虚拟 Key 鉴权、限额和审计，实际 OpenAI-compatible `/v1/...` 协议转发由本机 LiteLLM Proxy 处理
- 响应按 LiteLLM/上游返回的 `usage` 精准记录 token；无 usage 时用估算兜底

## 运行前准备

本机需要：

- Windows
- Docker Desktop，并保持运行
- Python 3.10+

华为云需要你在脚本中输入：

- 临时 AK
- 临时 SK
- STS Security Token
- Project ID
- Region，例如 `cn-north-4`
- 平台管理员账号和密码

脚本会自动：

- 生成 SWR 地址、组织名和仓库名
- 调用 SWR API 创建组织和仓库
- 自动查询并选择 4 vCPU / 16 GB 的通用计算型 ECS 规格
- 自动查询并选择 Ubuntu 64-bit 公共镜像

注意：STS token 用于华为云 API；Docker Registry 登录通常不能携带 STS token。脚本会先尝试用 `region@AK + SK` 自动登录 SWR；如果被 SWR 拒绝，才会现场提示你粘贴 SWR 控制台提供的 Docker 登录密码/登录密钥，并自动重试。

## 一键部署

双击：

```text
Start-Deploy.cmd
```

按提示输入参数。完成后到华为云 ECS 控制台查看实例公网 IP，访问：

```text
http://<ECS公网IP>/
```

使用部署时输入的管理员账号和管理员密码登录。

## 本地测试

```powershell
docker build -t maas-api-key-platform:local .
docker run --rm -p 8080:8080 -e ADMIN_USERNAME=admin -e ADMIN_PASSWORD=change-me -e SESSION_SECRET=local-secret maas-api-key-platform:local
```

然后访问：

```text
http://127.0.0.1:8080/
```

## 使用方式

1. 创建公司。
2. 给公司添加上游模型，填写 `apiurl`、`api key`、`modelID`。
3. 创建 Key 分组，并设置日/月输入输出 token 总额度，单位是百万 token。
4. 创建虚拟 Key，选择分组和上游模型；自定义额度可留空，系统会按组剩余额度平均分配。
5. 客户端把 OpenAI 兼容请求发到平台：

```text
http://<平台地址>/v1/...
Authorization: Bearer <虚拟Key>
```
