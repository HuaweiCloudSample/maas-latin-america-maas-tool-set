import hashlib
import json
import os
import secrets
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import psycopg2
import psycopg2.extras
import redis
import yaml
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field


APP_TITLE = "MaaS Virtual API Key Manager"
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres@/postgres?host=/run/postgresql")
REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", os.getenv("ADMIN_TOKEN", "change-me"))
SESSION_SECRET = os.getenv("SESSION_SECRET") or secrets.token_urlsafe(32)
LITELLM_URL = os.getenv("LITELLM_URL", "http://127.0.0.1:4000")
LITELLM_MASTER_KEY = os.getenv("LITELLM_MASTER_KEY", "sk-litellm-internal")
LITELLM_CONFIG_PATH = Path(os.getenv("LITELLM_CONFIG_PATH", "/app/litellm_config.yaml"))
TOKEN_UNIT = 1_000_000

app = FastAPI(title=APP_TITLE)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

static_dir = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/static", StaticFiles(directory=static_dir), name="static")


class LoginIn(BaseModel):
    username: str
    password: str


class CompanyIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)


class ProviderIn(BaseModel):
    company_id: int
    name: str = Field(min_length=1, max_length=80)
    base_url: str = Field(min_length=1, max_length=500)
    model: str = Field(min_length=1, max_length=120)
    api_key: str = Field(min_length=1, max_length=2048)


class GroupIn(BaseModel):
    company_id: int
    name: str = Field(min_length=1, max_length=120)
    daily_input_m: float | None = Field(default=None, ge=0)
    daily_output_m: float | None = Field(default=None, ge=0)
    monthly_input_m: float | None = Field(default=None, ge=0)
    monthly_output_m: float | None = Field(default=None, ge=0)


class VirtualKeyIn(BaseModel):
    group_id: int
    provider_id: int
    name: str = Field(min_length=1, max_length=80)
    owner_code: str | None = Field(default=None, max_length=120)
    daily_input_m: float | None = Field(default=None, ge=0)
    daily_output_m: float | None = Field(default=None, ge=0)
    monthly_input_m: float | None = Field(default=None, ge=0)
    monthly_output_m: float | None = Field(default=None, ge=0)


class VirtualKeyLimitIn(BaseModel):
    daily_input_m: float | None = Field(default=None, ge=0)
    daily_output_m: float | None = Field(default=None, ge=0)
    monthly_input_m: float | None = Field(default=None, ge=0)
    monthly_output_m: float | None = Field(default=None, ge=0)


class VirtualKeyOwnerIn(BaseModel):
    owner_code: str | None = Field(default=None, max_length=120)


def to_tokens(value: float | None) -> int | None:
    if value is None:
        return None
    return int(value * TOKEN_UNIT)


def clean_text(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    return value or None


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def today_key() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d")


def month_key() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m")


def db():
    return psycopg2.connect(DATABASE_URL, cursor_factory=psycopg2.extras.RealDictCursor)


def cache():
    return redis.from_url(REDIS_URL, decode_responses=True)


def session_token() -> str:
    raw = f"{ADMIN_USERNAME}:{ADMIN_PASSWORD}:{SESSION_SECRET}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def require_admin(authorization: str | None = Header(default=None)) -> None:
    expected = f"Bearer {session_token()}"
    if authorization != expected:
        raise HTTPException(status_code=401, detail="invalid admin session")


def init_db() -> None:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            create table if not exists companies (
                id serial primary key,
                name text not null,
                created_at timestamptz not null default now()
            );
            create table if not exists providers (
                id serial primary key,
                company_id integer not null references companies(id) on delete cascade,
                name text not null,
                base_url text not null,
                model text not null,
                api_key text not null,
                created_at timestamptz not null default now()
            );
            create table if not exists key_groups (
                id serial primary key,
                company_id integer not null references companies(id) on delete cascade,
                name text not null,
                daily_input_limit bigint,
                daily_output_limit bigint,
                monthly_input_limit bigint,
                monthly_output_limit bigint,
                created_at timestamptz not null default now()
            );
            create table if not exists virtual_keys (
                id serial primary key,
                name text not null,
                owner_code text,
                token text not null unique,
                group_id integer not null references key_groups(id) on delete cascade,
                provider_id integer not null references providers(id) on delete cascade,
                daily_input_limit bigint,
                daily_output_limit bigint,
                monthly_input_limit bigint,
                monthly_output_limit bigint,
                used_input bigint not null default 0,
                used_output bigint not null default 0,
                enabled boolean not null default true,
                created_at timestamptz not null default now()
            );
            create table if not exists usage_events (
                id bigserial primary key,
                virtual_key_id integer not null references virtual_keys(id) on delete cascade,
                group_id integer not null references key_groups(id) on delete cascade,
                provider_id integer not null references providers(id) on delete cascade,
                path text not null,
                input_tokens bigint not null default 0,
                output_tokens bigint not null default 0,
                source text not null,
                status_code integer not null,
                created_at timestamptz not null default now()
            );
            create index if not exists idx_virtual_keys_token on virtual_keys(token);
            create index if not exists idx_usage_events_created_at on usage_events(created_at);
            alter table virtual_keys add column if not exists owner_code text;
            alter table key_groups alter column daily_input_limit drop not null;
            alter table key_groups alter column daily_output_limit drop not null;
            alter table key_groups alter column monthly_input_limit drop not null;
            alter table key_groups alter column monthly_output_limit drop not null;
            """
        )
        cur.execute("insert into companies (name) select 'Default Company' where not exists (select 1 from companies)")


def litellm_model_name(provider_id: int, model: str) -> str:
    safe_model = "".join(ch if ch.isalnum() else "-" for ch in model.lower()).strip("-")[:80] or "model"
    return f"provider-{provider_id}-{safe_model}"


def litellm_api_base(base_url: str) -> str:
    clean = base_url.rstrip("/")
    return clean if clean.endswith("/v1") else f"{clean}/v1"


def sync_litellm_config(restart: bool = True) -> None:
    with db() as conn, conn.cursor() as cur:
        cur.execute("select id, name, base_url, model, api_key from providers order by id")
        providers = list(cur.fetchall())

    model_list = [
            {
                "model_name": litellm_model_name(provider["id"], provider["model"]),
                "litellm_params": {
                    "model": f"openai/{provider['model']}",
                    "api_key": provider["api_key"],
                    "api_base": litellm_api_base(provider["base_url"]),
                },
            }
            for provider in providers
    ]
    if not model_list:
        model_list = [
            {
                "model_name": "maas-no-provider-configured",
                "litellm_params": {
                    "model": "openai/gpt-4o-mini",
                    "api_key": "not-configured",
                },
            }
        ]

    config = {
        "model_list": model_list,
        "general_settings": {
            "master_key": LITELLM_MASTER_KEY,
        },
    }
    LITELLM_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    LITELLM_CONFIG_PATH.write_text(yaml.safe_dump(config, sort_keys=False, allow_unicode=True), encoding="utf-8")
    if restart:
        try:
            subprocess.run(["/usr/bin/supervisorctl", "restart", "litellm"], check=False, timeout=15)
        except Exception as exc:
            print(f"LiteLLM restart skipped: {exc}", flush=True)


@app.on_event("startup")
def startup() -> None:
    init_db()
    sync_litellm_config(restart=False)
    cache().set("service:last_start", now_iso())
    print(f"Admin username: {ADMIN_USERNAME}", flush=True)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(static_dir / "index.html")


@app.post("/api/login")
def login(payload: LoginIn) -> dict[str, str]:
    if payload.username != ADMIN_USERNAME or payload.password != ADMIN_PASSWORD:
        raise HTTPException(status_code=401, detail="invalid username or password")
    return {"token": session_token()}


@app.get("/api/bootstrap")
def bootstrap() -> dict[str, Any]:
    return {"title": APP_TITLE, "admin_username": ADMIN_USERNAME}


@app.get("/api/health")
async def health() -> dict[str, Any]:
    status = {"api": "ok", "postgres": "ok", "redis": "ok", "litellm": "unknown"}
    with db() as conn, conn.cursor() as cur:
        cur.execute("select 1")
    cache().ping()
    try:
        async with httpx.AsyncClient(timeout=2) as client:
            response = await client.get(f"{LITELLM_URL}/health")
        status["litellm"] = "ok" if response.status_code < 500 else "degraded"
    except Exception:
        status["litellm"] = "not_configured"
    return status


@app.get("/api/companies", dependencies=[Depends(require_admin)])
def list_companies() -> list[dict[str, Any]]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("select id, name, created_at from companies order by id desc")
        return list(cur.fetchall())


@app.post("/api/companies", dependencies=[Depends(require_admin)])
def create_company(payload: CompanyIn) -> dict[str, Any]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("insert into companies (name) values (%s) returning id, name, created_at", (payload.name,))
        return dict(cur.fetchone())


@app.delete("/api/companies/{company_id}", dependencies=[Depends(require_admin)])
def delete_company(company_id: int) -> dict[str, str]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("delete from companies where id=%s", (company_id,))
    return {"status": "deleted"}


@app.get("/api/providers", dependencies=[Depends(require_admin)])
def list_providers() -> list[dict[str, Any]]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select p.id, p.company_id, c.name as company_name, p.name, p.base_url, p.model, p.created_at
            from providers p join companies c on c.id = p.company_id
            order by p.id desc
            """
        )
        return list(cur.fetchall())


@app.post("/api/providers", dependencies=[Depends(require_admin)])
def create_provider(payload: ProviderIn) -> dict[str, Any]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            insert into providers (company_id, name, base_url, model, api_key)
            values (%s, %s, %s, %s, %s)
            returning id, company_id, name, base_url, model, created_at
            """,
            (payload.company_id, payload.name, payload.base_url, payload.model, payload.api_key),
        )
        row = dict(cur.fetchone())
    sync_litellm_config()
    return row


@app.delete("/api/providers/{provider_id}", dependencies=[Depends(require_admin)])
def delete_provider(provider_id: int) -> dict[str, str]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("delete from providers where id=%s", (provider_id,))
    sync_litellm_config()
    return {"status": "deleted"}


@app.get("/api/groups", dependencies=[Depends(require_admin)])
def list_groups() -> list[dict[str, Any]]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select g.*, c.name as company_name,
                   (select count(*) from virtual_keys vk where vk.group_id = g.id) as key_count
            from key_groups g join companies c on c.id = g.company_id
            order by g.id desc
            """
        )
        return list(cur.fetchall())


@app.post("/api/groups", dependencies=[Depends(require_admin)])
def create_group(payload: GroupIn) -> dict[str, Any]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            insert into key_groups
            (company_id, name, daily_input_limit, daily_output_limit, monthly_input_limit, monthly_output_limit)
            values (%s, %s, %s, %s, %s, %s)
            returning *
            """,
            (
                payload.company_id,
                payload.name,
                to_tokens(payload.daily_input_m),
                to_tokens(payload.daily_output_m),
                to_tokens(payload.monthly_input_m),
                to_tokens(payload.monthly_output_m),
            ),
        )
        return dict(cur.fetchone())


@app.delete("/api/groups/{group_id}", dependencies=[Depends(require_admin)])
def delete_group(group_id: int) -> dict[str, str]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("delete from key_groups where id=%s", (group_id,))
    return {"status": "deleted"}


def validate_group_key_limits(cur: Any, group_id: int, limits: dict[str, int | None], exclude_key_id: int | None = None) -> None:
    cur.execute("select * from key_groups where id=%s", (group_id,))
    group = cur.fetchone()
    if not group:
        raise HTTPException(status_code=404, detail="group not found")
    for col, group_col in [
        ("daily_input_limit", "daily_input_limit"),
        ("daily_output_limit", "daily_output_limit"),
        ("monthly_input_limit", "monthly_input_limit"),
        ("monthly_output_limit", "monthly_output_limit"),
    ]:
        custom = limits[col]
        group_limit = group[group_col]
        if custom is not None and group_limit is not None and custom > group_limit:
            raise HTTPException(status_code=400, detail=f"{col} exceeds group limit")
        if exclude_key_id is None:
            cur.execute(f"select coalesce(sum({col}), 0) as total from virtual_keys where group_id=%s and {col} is not null", (group_id,))
        else:
            cur.execute(
                f"select coalesce(sum({col}), 0) as total from virtual_keys where group_id=%s and id<>%s and {col} is not null",
                (group_id, exclude_key_id),
            )
        total = int(cur.fetchone()["total"] or 0)
        if custom is not None and group_limit is not None and total + custom > group_limit:
            raise HTTPException(status_code=400, detail=f"group {col} total exceeds group limit")


@app.get("/api/virtual-keys", dependencies=[Depends(require_admin)])
def list_virtual_keys() -> list[dict[str, Any]]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select vk.*, p.name as provider_name, p.model, g.name as group_name, c.name as company_name,
                   g.daily_input_limit as group_daily_input_limit,
                   g.daily_output_limit as group_daily_output_limit,
                   g.monthly_input_limit as group_monthly_input_limit,
                   g.monthly_output_limit as group_monthly_output_limit
            from virtual_keys vk
            join providers p on p.id = vk.provider_id
            join key_groups g on g.id = vk.group_id
            join companies c on c.id = g.company_id
            order by vk.id desc
            """
        )
        rows = [dict(row) for row in cur.fetchall()]
        for row in rows:
            row["daily_input_limit_custom"] = row["daily_input_limit"] is not None
            row["daily_output_limit_custom"] = row["daily_output_limit"] is not None
            row["monthly_input_limit_custom"] = row["monthly_input_limit"] is not None
            row["monthly_output_limit_custom"] = row["monthly_output_limit"] is not None
            row["daily_input_limit"] = derived_key_limit(cur, row, "daily_input_limit", "group_daily_input_limit")
            row["daily_output_limit"] = derived_key_limit(cur, row, "daily_output_limit", "group_daily_output_limit")
            row["monthly_input_limit"] = derived_key_limit(cur, row, "monthly_input_limit", "group_monthly_input_limit")
            row["monthly_output_limit"] = derived_key_limit(cur, row, "monthly_output_limit", "group_monthly_output_limit")
        return rows


@app.post("/api/virtual-keys", dependencies=[Depends(require_admin)])
def create_virtual_key(payload: VirtualKeyIn) -> dict[str, Any]:
    limits = {
        "daily_input_limit": to_tokens(payload.daily_input_m),
        "daily_output_limit": to_tokens(payload.daily_output_m),
        "monthly_input_limit": to_tokens(payload.monthly_input_m),
        "monthly_output_limit": to_tokens(payload.monthly_output_m),
    }
    token = f"vmaas_{secrets.token_urlsafe(32)}"
    with db() as conn, conn.cursor() as cur:
        validate_group_key_limits(cur, payload.group_id, limits)
        cur.execute(
            "select 1 from providers p join key_groups g on g.company_id = p.company_id where p.id=%s and g.id=%s",
            (payload.provider_id, payload.group_id),
        )
        if not cur.fetchone():
            raise HTTPException(status_code=400, detail="provider and group must belong to the same company")
        cur.execute(
            """
            insert into virtual_keys
            (name, owner_code, token, group_id, provider_id, daily_input_limit, daily_output_limit, monthly_input_limit, monthly_output_limit)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            returning *
            """,
            (
                payload.name,
                clean_text(payload.owner_code),
                token,
                payload.group_id,
                payload.provider_id,
                limits["daily_input_limit"],
                limits["daily_output_limit"],
                limits["monthly_input_limit"],
                limits["monthly_output_limit"],
            ),
        )
        return dict(cur.fetchone())


@app.patch("/api/virtual-keys/{key_id}/owner", dependencies=[Depends(require_admin)])
def update_virtual_key_owner(key_id: int, payload: VirtualKeyOwnerIn) -> dict[str, Any]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            "update virtual_keys set owner_code=%s where id=%s returning id, owner_code",
            (clean_text(payload.owner_code), key_id),
        )
        row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="virtual key not found")
    return dict(row)


@app.patch("/api/virtual-keys/{key_id}/limits", dependencies=[Depends(require_admin)])
def update_virtual_key_limits(key_id: int, payload: VirtualKeyLimitIn) -> dict[str, Any]:
    limits = {
        "daily_input_limit": to_tokens(payload.daily_input_m),
        "daily_output_limit": to_tokens(payload.daily_output_m),
        "monthly_input_limit": to_tokens(payload.monthly_input_m),
        "monthly_output_limit": to_tokens(payload.monthly_output_m),
    }
    with db() as conn, conn.cursor() as cur:
        cur.execute("select id, group_id from virtual_keys where id=%s", (key_id,))
        key = cur.fetchone()
        if not key:
            raise HTTPException(status_code=404, detail="virtual key not found")
        validate_group_key_limits(cur, key["group_id"], limits, exclude_key_id=key_id)
        cur.execute(
            """
            update virtual_keys
            set daily_input_limit=%s,
                daily_output_limit=%s,
                monthly_input_limit=%s,
                monthly_output_limit=%s
            where id=%s
            returning *
            """,
            (
                limits["daily_input_limit"],
                limits["daily_output_limit"],
                limits["monthly_input_limit"],
                limits["monthly_output_limit"],
                key_id,
            ),
        )
        return dict(cur.fetchone())


@app.patch("/api/virtual-keys/{key_id}/toggle", dependencies=[Depends(require_admin)])
def toggle_virtual_key(key_id: int) -> dict[str, Any]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("update virtual_keys set enabled = not enabled where id=%s returning id, enabled", (key_id,))
        row = cur.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="virtual key not found")
    return dict(row)


@app.delete("/api/virtual-keys/{key_id}", dependencies=[Depends(require_admin)])
def delete_virtual_key(key_id: int) -> dict[str, str]:
    with db() as conn, conn.cursor() as cur:
        cur.execute("delete from virtual_keys where id=%s", (key_id,))
    return {"status": "deleted"}


@app.get("/api/usage/summary", dependencies=[Depends(require_admin)])
def usage_summary() -> dict[str, list[dict[str, Any]]]:
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select g.id as group_id, g.name as group_name, c.name as company_name,
                   coalesce(sum(vk.used_input), 0) as used_input,
                   coalesce(sum(vk.used_output), 0) as used_output,
                   coalesce(sum(vk.used_input + vk.used_output), 0) as total_tokens
            from key_groups g
            join companies c on c.id = g.company_id
            left join virtual_keys vk on vk.group_id = g.id
            group by g.id, g.name, c.name
            order by total_tokens desc, g.id desc
            """
        )
        groups = list(cur.fetchall())
        cur.execute(
            """
            select vk.id as virtual_key_id, vk.name, vk.owner_code, g.name as group_name, c.name as company_name,
                   vk.used_input, vk.used_output, (vk.used_input + vk.used_output) as total_tokens
            from virtual_keys vk
            join key_groups g on g.id = vk.group_id
            join companies c on c.id = g.company_id
            order by total_tokens desc, vk.id desc
            limit 5
            """
        )
        top_keys = list(cur.fetchall())
    return {"groups": groups, "top_keys": top_keys}


def counter_names(key_id: int, group_id: int) -> dict[str, str]:
    day = today_key()
    month = month_key()
    return {
        "key_day_in": f"usage:key:{key_id}:day:{day}:input",
        "key_day_out": f"usage:key:{key_id}:day:{day}:output",
        "key_month_in": f"usage:key:{key_id}:month:{month}:input",
        "key_month_out": f"usage:key:{key_id}:month:{month}:output",
        "group_day_in": f"usage:group:{group_id}:day:{day}:input",
        "group_day_out": f"usage:group:{group_id}:day:{day}:output",
        "group_month_in": f"usage:group:{group_id}:month:{month}:input",
        "group_month_out": f"usage:group:{group_id}:month:{month}:output",
    }


def current_usage(r: redis.Redis, name: str) -> int:
    return int(r.get(name) or 0)


def derived_key_limit(cur: Any, row: dict[str, Any], key_col: str, group_col: str) -> int | None:
    if row[key_col] is not None:
        return int(row[key_col])
    if row[group_col] is None:
        return None
    group_limit = int(row[group_col])
    cur.execute(
        f"""
        select
          coalesce(sum({key_col}), 0) as custom_total,
          count(*) filter (where {key_col} is null) as default_count
        from virtual_keys
        where group_id=%s and enabled=true
        """,
        (row["group_id"],),
    )
    stats = cur.fetchone()
    remaining = max(group_limit - int(stats["custom_total"] or 0), 0)
    default_count = max(int(stats["default_count"] or 1), 1)
    return remaining // default_count


def ensure_limit(label: str, used: int, limit: int | None) -> None:
    if limit is not None and used >= limit:
        raise HTTPException(status_code=429, detail=f"{label} quota exceeded")


def enforce_quota(cur: Any, r: redis.Redis, row: dict[str, Any]) -> None:
    names = counter_names(row["id"], row["group_id"])
    def group_limit(name: str) -> int | None:
        if row[name] is None:
            return None
        return int(row[name])

    checks = [
        ("key daily input", names["key_day_in"], derived_key_limit(cur, row, "daily_input_limit", "group_daily_input_limit")),
        ("key daily output", names["key_day_out"], derived_key_limit(cur, row, "daily_output_limit", "group_daily_output_limit")),
        ("key monthly input", names["key_month_in"], derived_key_limit(cur, row, "monthly_input_limit", "group_monthly_input_limit")),
        ("key monthly output", names["key_month_out"], derived_key_limit(cur, row, "monthly_output_limit", "group_monthly_output_limit")),
        ("group daily input", names["group_day_in"], group_limit("group_daily_input_limit")),
        ("group daily output", names["group_day_out"], group_limit("group_daily_output_limit")),
        ("group monthly input", names["group_month_in"], group_limit("group_monthly_input_limit")),
        ("group monthly output", names["group_month_out"], group_limit("group_monthly_output_limit")),
    ]
    for label, counter, limit in checks:
        ensure_limit(label, current_usage(r, counter), limit)


def estimate_tokens_from_body(body: bytes) -> int:
    if not body:
        return 0
    try:
        payload = json.loads(body.decode("utf-8"))
        text = json.dumps(payload.get("messages", payload), ensure_ascii=False)
    except Exception:
        text = body.decode("utf-8", errors="ignore")
    return max(1, len(text) // 4)


def extract_usage(response: httpx.Response, request_body: bytes) -> tuple[int, int, str]:
    fallback_input = estimate_tokens_from_body(request_body)
    if "application/json" not in response.headers.get("content-type", ""):
        return fallback_input, 0, "estimated"
    try:
        payload = response.json()
    except Exception:
        return fallback_input, 0, "estimated"
    usage = payload.get("usage") if isinstance(payload, dict) else None
    if not usage:
        return fallback_input, 0, "estimated"
    input_tokens = int(usage.get("prompt_tokens") or usage.get("input_tokens") or fallback_input)
    output_tokens = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)
    return input_tokens, output_tokens, "upstream_usage"


def rewrite_body_for_litellm(body: bytes, provider_id: int, model: str) -> bytes:
    if not body:
        return body
    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception:
        return body
    if not isinstance(payload, dict):
        return body
    payload["model"] = litellm_model_name(provider_id, model)
    if payload.get("stream") is True:
        stream_options = payload.get("stream_options") if isinstance(payload.get("stream_options"), dict) else {}
        stream_options["include_usage"] = True
        payload["stream_options"] = stream_options
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def record_usage(cur: Any, r: redis.Redis, row: dict[str, Any], path: str, status_code: int, input_tokens: int, output_tokens: int, source: str) -> None:
    names = counter_names(row["id"], row["group_id"])
    pipe = r.pipeline()
    for counter, amount, ttl in [
        (names["key_day_in"], input_tokens, 172800),
        (names["key_day_out"], output_tokens, 172800),
        (names["key_month_in"], input_tokens, 5356800),
        (names["key_month_out"], output_tokens, 5356800),
        (names["group_day_in"], input_tokens, 172800),
        (names["group_day_out"], output_tokens, 172800),
        (names["group_month_in"], input_tokens, 5356800),
        (names["group_month_out"], output_tokens, 5356800),
    ]:
        pipe.incrby(counter, amount)
        pipe.expire(counter, ttl)
    pipe.execute()
    cur.execute(
        """
        update virtual_keys set used_input = used_input + %s, used_output = used_output + %s where id=%s;
        insert into usage_events
        (virtual_key_id, group_id, provider_id, path, input_tokens, output_tokens, source, status_code)
        values (%s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            input_tokens,
            output_tokens,
            row["id"],
            row["id"],
            row["group_id"],
            row["provider_id"],
            path,
            input_tokens,
            output_tokens,
            source,
            status_code,
        ),
    )


@app.api_route("/v1/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def proxy_openai(path: str, request: Request, authorization: str | None = Header(default=None)) -> Response:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="missing virtual key")

    token = authorization.removeprefix("Bearer ").strip()
    r = cache()
    with db() as conn, conn.cursor() as cur:
        cur.execute(
            """
            select vk.*, p.base_url, p.model,
                   g.daily_input_limit as group_daily_input_limit,
                   g.daily_output_limit as group_daily_output_limit,
                   g.monthly_input_limit as group_monthly_input_limit,
                   g.monthly_output_limit as group_monthly_output_limit
            from virtual_keys vk
            join providers p on p.id = vk.provider_id
            join key_groups g on g.id = vk.group_id
            where vk.token=%s
            """,
            (token,),
        )
        row = cur.fetchone()
        if not row or not row["enabled"]:
            raise HTTPException(status_code=401, detail="invalid virtual key")
        enforce_quota(cur, r, row)

        body = await request.body()
        litellm_body = rewrite_body_for_litellm(body, row["provider_id"], row["model"])
        headers = dict(request.headers)
        if LITELLM_MASTER_KEY:
            headers["authorization"] = f"Bearer {LITELLM_MASTER_KEY}"
        else:
            headers.pop("authorization", None)
        headers.pop("host", None)
        headers.pop("content-length", None)
        url = f"{LITELLM_URL.rstrip('/')}/v1/{path}"

        async with httpx.AsyncClient(timeout=120) as client:
            upstream = await client.request(request.method, url, content=litellm_body, headers=headers)

        input_tokens, output_tokens, source = extract_usage(upstream, body)
        record_usage(cur, r, row, f"/v1/{path}", upstream.status_code, input_tokens, output_tokens, source)

        content_type = upstream.headers.get("content-type", "")
        if "application/json" in content_type:
            return JSONResponse(status_code=upstream.status_code, content=upstream.json())
        return Response(status_code=upstream.status_code, content=upstream.content, media_type=content_type or None)
