$ErrorActionPreference = "Stop"

function Write-Step($Current, $Total, $Message) {
  $percent = [int](($Current / $Total) * 100)
  Write-Progress -Activity "MaaS API Key Management Deployment" -Status $Message -PercentComplete $percent
  Write-Host "[$Current/$Total] $Message" -ForegroundColor Cyan
}

function Read-SecretText($PromptText) {
  $secret = Read-Host $PromptText -AsSecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
  try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

function Invoke-Checked($FilePath, [string[]]$Arguments) {
  & $FilePath @Arguments
  if ($LASTEXITCODE -ne 0) {
    throw "Command failed: $FilePath $($Arguments -join ' ')"
  }
}

function Invoke-DeployPy([string[]]$Arguments) {
  $deployPy = Join-Path $PSScriptRoot "deploy.py"
  $allArguments = @($deployPy) + $Arguments
  Invoke-Checked $venvPython $allArguments
}

function Refresh-ProcessPath {
  $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
  $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
  $env:Path = "$machinePath;$userPath"

  $dockerCli = Join-Path $env:ProgramFiles "Docker\Docker\resources\bin"
  if ((Test-Path $dockerCli) -and ($env:Path -notlike "*$dockerCli*")) {
    $env:Path = "$env:Path;$dockerCli"
  }
}

function Install-WingetPackage($PackageId, $DisplayName) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "winget was not found. Please install App Installer from Microsoft Store, then rerun this script."
  }

  Write-Host "$DisplayName was not found. Installing with winget..." -ForegroundColor Yellow
  winget install --id $PackageId --exact --silent --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) {
    throw "Failed to install $DisplayName with winget. Please install it manually and rerun this script."
  }
  Refresh-ProcessPath
}

function Test-PythonUsable {
  $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
  if (-not $pythonCmd) { return $false }

  python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" *> $null
  return ($LASTEXITCODE -eq 0)
}

function Test-PythonPath($Path) {
  if (-not (Test-Path $Path)) { return $false }
  & $Path -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" *> $null
  return ($LASTEXITCODE -eq 0)
}

function Resolve-PythonPath {
  $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
  if ($pythonCmd) {
    python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" *> $null
    if ($LASTEXITCODE -eq 0) { return $pythonCmd.Source }
  }

  $candidates = @(
    (Join-Path $env:LocalAppData "Programs\Python\Python312\python.exe"),
    (Join-Path $env:LocalAppData "Programs\Python\Python311\python.exe"),
    (Join-Path $env:LocalAppData "Programs\Python\Python310\python.exe"),
    (Join-Path $env:ProgramFiles "Python312\python.exe"),
    (Join-Path $env:ProgramFiles "Python311\python.exe"),
    (Join-Path $env:ProgramFiles "Python310\python.exe")
  )

  foreach ($candidate in $candidates) {
    if (Test-PythonPath $candidate) { return $candidate }
  }

  return $null
}

function Ensure-Python {
  Refresh-ProcessPath
  $pythonPath = Resolve-PythonPath
  if ($pythonPath) {
    $script:python = $pythonPath
    Write-Host "Python 3.10+ found. Skipping Python installation." -ForegroundColor Green
    return
  }

  Install-WingetPackage "Python.Python.3.12" "Python 3.12"
  $pythonPath = Resolve-PythonPath
  if (-not $pythonPath) {
    throw "Python 3.10+ is still not usable after installation. Please reopen this terminal or install Python manually."
  }
  $script:python = $pythonPath
}

function Test-IsAdmin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-OptionalFeatureEnabled($FeatureName) {
  try {
    $feature = Get-WindowsOptionalFeature -Online -FeatureName $FeatureName -ErrorAction SilentlyContinue
    return ($feature -and $feature.State -eq "Enabled")
  } catch {
    return $false
  }
}

function Invoke-ElevatedVirtualizationSetup {
  $setupScript = @'
$ErrorActionPreference = "Continue"
$features = @(
  "Microsoft-Windows-Subsystem-Linux",
  "VirtualMachinePlatform",
  "Containers",
  "Microsoft-Hyper-V-All"
)

foreach ($feature in $features) {
  $item = Get-WindowsOptionalFeature -Online -FeatureName $feature -ErrorAction SilentlyContinue
  if ($item -and $item.State -ne "Enabled") {
    Write-Host "Enabling Windows feature: $feature"
    Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -NoRestart
  }
}

bcdedit /set hypervisorlaunchtype auto
wsl --install --no-distribution
wsl --update
'@

  $setupPath = Join-Path $env:TEMP "maas-enable-virtualization.ps1"
  Set-Content -Path $setupPath -Value $setupScript -Encoding UTF8
  Write-Host "Opening an administrator window to enable Windows virtualization features..." -ForegroundColor Yellow
  Start-Process powershell -Verb RunAs -Wait -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$setupPath`""
}

function Ensure-WindowsVirtualization {
  $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
  if ($cpu) {
    if ($cpu.PSObject.Properties.Name -contains "SecondLevelAddressTranslationExtensions" -and -not $cpu.SecondLevelAddressTranslationExtensions) {
      Write-Host "Warning: Windows reports that CPU SLAT support is unavailable. Continuing setup because this can be a false negative on some systems." -ForegroundColor Yellow
    }
    if ($cpu.PSObject.Properties.Name -contains "VirtualizationFirmwareEnabled" -and -not $cpu.VirtualizationFirmwareEnabled) {
      Write-Host ""
      Write-Host "Action required: CPU virtualization is disabled in BIOS/UEFI." -ForegroundColor Red
      Write-Host "Docker Desktop cannot start until hardware virtualization is enabled." -ForegroundColor Yellow
      Write-Host ""
      Write-Host "Please reboot into BIOS/UEFI and enable one of these options:" -ForegroundColor Yellow
      Write-Host "  - Intel CPU: Intel VT-x, Intel Virtualization Technology, or VT-d"
      Write-Host "  - AMD CPU: AMD-V, SVM Mode, or Secure Virtual Machine"
      Write-Host ""
      Write-Host "After saving BIOS/UEFI changes, reboot Windows and run Start-Deploy.cmd again." -ForegroundColor Yellow
      exit 1
    }
  }

  $requiredFeatures = @(
    "Microsoft-Windows-Subsystem-Linux",
    "VirtualMachinePlatform"
  )
  $missingFeatures = @()
  foreach ($feature in $requiredFeatures) {
    if (-not (Get-OptionalFeatureEnabled $feature)) {
      $missingFeatures += $feature
    }
  }

  $hypervisorLaunchType = ""
  try {
    $bcdOutput = bcdedit /enum "{current}" 2>$null
    $hypervisorLine = $bcdOutput | Where-Object { $_ -match "hypervisorlaunchtype" } | Select-Object -First 1
    if ($hypervisorLine) {
      $hypervisorLaunchType = ($hypervisorLine -split "\s+")[-1]
    }
  } catch {
    $hypervisorLaunchType = ""
  }

  if ($missingFeatures.Count -eq 0 -and $hypervisorLaunchType -ne "Off") {
    Write-Host "Windows virtualization features found. Skipping virtualization setup." -ForegroundColor Green
    return
  }

  if (Test-IsAdmin) {
    Invoke-ElevatedVirtualizationSetup
  } else {
    Invoke-ElevatedVirtualizationSetup
  }

  throw "Windows virtualization features were enabled or repaired. Please restart Windows, then rerun Start-Deploy.cmd."
}

function Start-DockerDesktop {
  $service = Get-Service -Name "com.docker.service" -ErrorAction SilentlyContinue
  if ($service -and $service.Status -ne "Running") {
    Write-Host "Starting Docker service..." -ForegroundColor Yellow
    Start-Service -Name "com.docker.service" -ErrorAction SilentlyContinue
  }

  $dockerDesktop = Join-Path $env:ProgramFiles "Docker\Docker\Docker Desktop.exe"
  if (Test-Path $dockerDesktop) {
    Write-Host "Starting Docker Desktop..." -ForegroundColor Yellow
    Start-Process -FilePath $dockerDesktop -WindowStyle Hidden
  }
}

function Test-DockerReady {
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { return $false }

  $oldErrorActionPreference = $ErrorActionPreference
  try {
    $ErrorActionPreference = "Continue"
    docker info *> $null
    return ($LASTEXITCODE -eq 0)
  } catch {
    return $false
  } finally {
    $ErrorActionPreference = $oldErrorActionPreference
  }
}

function Wait-DockerReady($TimeoutSeconds = 300) {
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  while ((Get-Date) -lt $deadline) {
    if (Test-DockerReady) { return $true }
    Start-Sleep -Seconds 5
  }
  return $false
}

function Ensure-Docker {
  Refresh-ProcessPath
  Ensure-WindowsVirtualization

  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Install-WingetPackage "Docker.DockerDesktop" "Docker Desktop"
  }

  Refresh-ProcessPath
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker CLI is still not available after installation. Please restart Windows and rerun this script."
  }

  if (Test-DockerReady) {
    Write-Host "Docker is running. Skipping Docker installation/startup." -ForegroundColor Green
    return
  }

  Start-DockerDesktop
  Write-Host "Waiting for Docker Desktop to become ready..." -ForegroundColor Yellow
  if (-not (Wait-DockerReady 300)) {
    throw "Docker Desktop is installed but not ready. Please finish Docker Desktop setup, make sure WSL 2 is enabled if prompted, then rerun this script."
  }
}

$root = Split-Path -Parent $PSScriptRoot
$venv = Join-Path $root ".deploy-venv"
$python = "python"
$total = 8

Write-Host ""
Write-Host "MaaS API Key Management one-click deployment" -ForegroundColor Green
Write-Host "This script creates VPC/ECS and builds the container image on the ECS instance."
Write-Host "Ubuntu image and 4 vCPU / 16 GB ECS flavor are selected automatically."
Write-Host "Local Docker Desktop is not required."
Write-Host ""

Write-Step 1 $total "Checking Python"
Ensure-Python

Write-Step 2 $total "Creating deployment runtime"
if (-not (Test-Path $venv)) { & $python -m venv $venv }
$venvPython = Join-Path $venv "Scripts\python.exe"
Invoke-Checked $venvPython @("-m", "pip", "install", "--upgrade", "pip")
Invoke-Checked $venvPython @("-m", "pip", "install", "-r", (Join-Path $PSScriptRoot "requirements.txt"))

Write-Step 3 $total "Reading required parameters"
$config = [ordered]@{}
$config.region = Read-Host "Huawei Cloud Region, for example cn-north-4"
$config.project_id = Read-Host "Huawei Cloud Project ID"
$config.ak = Read-Host "Temporary AK"
$config.sk = Read-SecretText "Temporary SK"
$config.security_token = Read-SecretText "STS Security Token"
$config.admin_username = Read-Host "Platform admin username [admin]"
if ([string]::IsNullOrWhiteSpace($config.admin_username)) { $config.admin_username = "admin" }
$config.admin_password = Read-SecretText "Platform admin password"
$config.litellm_master_key = Read-SecretText "LiteLLM Master Key (optional)"
if ([string]::IsNullOrWhiteSpace($config.litellm_master_key)) {
  $config.litellm_master_key = "sk-litellm-" + (-join ((48..57) + (65..90) + (97..122) | Get-Random -Count 32 | ForEach-Object {[char]$_}))
}
$config.ecs_name = "maas-api-key-platform"
$config.bandwidth_size = 300
$config.swr_server = "swr.$($config.region).myhuaweicloud.com"
$config.swr_repo = "maas-api-key-platform"
$config.swr_username = "$($config.region)@$($config.ak)"
$config.swr_password = $config.sk
$config.session_secret = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 32 | ForEach-Object {[char]$_})
$config.ecs_admin_pass = "Huawei@123"
Write-Host "Generated defaults: 4 vCPU / 16 GB ECS flavor, Ubuntu image, 300 Mbit/s EIP bandwidth, remote ECS image build." -ForegroundColor Yellow
Write-Host "ECS default login user is root; default password is saved in deploy_config.json." -ForegroundColor Yellow

$configPath = Join-Path $root "deploy_config.json"
$config | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $configPath

Write-Step 4 $total "Detecting public IP"
Invoke-DeployPy @("detect-ip", "--config", $configPath)

Write-Step 5 $total "Preparing ECS flavor and Ubuntu image"
Invoke-DeployPy @("prepare-defaults", "--config", $configPath)

Write-Step 6 $total "Creating VPC, security group, and public IP"
Invoke-DeployPy @("create-network", "--config", $configPath)

Write-Step 7 $total "Creating ECS and remote container build"
Invoke-DeployPy @("create-ecs", "--config", $configPath, "--root", $root)

Write-Step 8 $total "Printing resource names and access info"
Invoke-DeployPy @("summary", "--config", $configPath)
Write-Progress -Activity "MaaS API Key Management Deployment" -Completed
