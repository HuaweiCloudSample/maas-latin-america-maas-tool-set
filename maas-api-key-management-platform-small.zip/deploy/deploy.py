import argparse
import base64
import getpass
import io
import json
import re
import secrets
import subprocess
import sys
import tarfile
import time
from pathlib import Path
from typing import Any

import requests
from huaweicloudsdkcore.auth.credentials import BasicCredentials
from huaweicloudsdkcore.exceptions.exceptions import ClientRequestException
from huaweicloudsdkcore.http.http_config import HttpConfig
from huaweicloudsdkecs.v2 import *
from huaweicloudsdkecs.v2.region.ecs_region import EcsRegion
from huaweicloudsdkims.v2 import *
from huaweicloudsdkims.v2.region.ims_region import ImsRegion
from huaweicloudsdkswr.v2 import *
from huaweicloudsdkswr.v2.region.swr_region import SwrRegion
from huaweicloudsdkvpc.v2 import *
from huaweicloudsdkvpc.v2.region.vpc_region import VpcRegion

requests.packages.urllib3.disable_warnings()


def log(message: str) -> None:
    print(message, flush=True)


def run(command: list[str], cwd: str | None = None, input_text: str | None = None) -> None:
    log("> " + " ".join(command))
    result = subprocess.run(command, cwd=cwd, input=input_text, text=True)
    if result.returncode != 0:
        raise SystemExit(result.returncode)


def load_config(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save_config(path: Path, config: dict[str, Any]) -> None:
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


def credentials(config: dict[str, Any]) -> BasicCredentials:
    creds = BasicCredentials(config["ak"], config["sk"], config["project_id"])
    token = config.get("security_token")
    if token:
        creds = creds.with_security_token(token)
    return creds


def sdk_http_config() -> HttpConfig:
    return HttpConfig(ignore_ssl_verification=True)


def vpc_client(config: dict[str, Any]) -> VpcClient:
    return VpcClient.new_builder().with_http_config(sdk_http_config()).with_credentials(credentials(config)).with_region(VpcRegion.value_of(config["region"])).build()


def ecs_client(config: dict[str, Any]) -> EcsClient:
    return EcsClient.new_builder().with_http_config(sdk_http_config()).with_credentials(credentials(config)).with_region(EcsRegion.value_of(config["region"])).build()


def ims_client(config: dict[str, Any]) -> ImsClient:
    return ImsClient.new_builder().with_http_config(sdk_http_config()).with_credentials(credentials(config)).with_region(ImsRegion.value_of(config["region"])).build()


def swr_client(config: dict[str, Any]) -> SwrClient:
    return SwrClient.new_builder().with_http_config(sdk_http_config()).with_credentials(credentials(config)).with_region(SwrRegion.value_of(config["region"])).build()


def safe_namespace(project_id: str) -> str:
    suffix = re.sub(r"[^a-z0-9-]", "", project_id.lower())[:12] or secrets.token_hex(4)
    return f"maas-{suffix}"


def detect_ip(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    response = requests.get("https://api.ipify.org?format=json", timeout=10, verify=False)
    response.raise_for_status()
    public_ip = response.json()["ip"]
    config["operator_ip"] = public_ip
    save_config(args.config, config)
    log(f"检测到本机公网 IP: {public_ip}，安全组将只允许 {public_ip}/32 访问 80 和 8080。")


def ensure_swr(config: dict[str, Any]) -> None:
    client = swr_client(config)
    namespace = config.get("swr_namespace") or safe_namespace(config["project_id"])
    config["swr_namespace"] = namespace
    repo = config.get("swr_repo") or "maas-api-key-platform"
    config["swr_repo"] = repo
    config["swr_repository"] = f"{namespace}/{repo}"

    try:
        req = ListNamespacesRequest(filter=f"namespace::{namespace}")
        existing = client.list_namespaces(req)
        namespaces = getattr(existing, "namespaces", None) or []
    except Exception:
        namespaces = []

    if not namespaces:
        req = CreateNamespaceRequest(body=CreateNamespaceRequestBody(namespace=namespace))
        client.create_namespace(req)
        log(f"SWR 组织已创建: {namespace}")
    else:
        log(f"SWR 组织已存在: {namespace}")

    try:
        req = CreateRepoRequest(
            namespace=namespace,
            body=CreateRepoRequestBody(repository=repo, is_public=False, category="linux", description="MaaS API Key Management Platform"),
        )
        client.create_repo(req)
        log(f"SWR 镜像仓库已创建: {namespace}/{repo}")
    except Exception as exc:
        message = str(exc)
        if "409" in message or "exist" in message.lower() or "already" in message.lower():
            log(f"SWR 镜像仓库已存在: {namespace}/{repo}")
        else:
            raise


def choose_flavor(config: dict[str, Any]) -> str:
    client = ecs_client(config)
    response = client.list_flavors(ListFlavorsRequest())
    flavors = getattr(response, "flavors", None) or []
    candidates = [f for f in flavors if str(getattr(f, "vcpus", "")) == "4" and int(getattr(f, "ram", 0) or 0) == 16384]
    if not candidates:
        raise RuntimeError("未在当前 Region 找到 4 vCPU / 16 GB 的 ECS 规格，请在华为云控制台确认该 Region 是否售卖此规格。")

    def score(flavor: Any) -> tuple[int, str]:
        name = (getattr(flavor, "name", None) or getattr(flavor, "id", "") or "").lower()
        prefixes = ["s7.", "s6.", "s3.", "sn3.", "c7.", "c6."]
        for idx, prefix in enumerate(prefixes):
            if name.startswith(prefix):
                return (idx, name)
        return (99, name)

    chosen = sorted(candidates, key=score)[0]
    flavor_id = getattr(chosen, "id", None) or getattr(chosen, "name")
    log(f"已选择 ECS 规格: {flavor_id} (4 vCPU / 16 GB)")
    return flavor_id


def choose_image(config: dict[str, Any]) -> str:
    client = ims_client(config)
    req = ListImagesRequest(imagetype="gold", isregistered="true", platform="Ubuntu", os_bit="64", status="active", limit=100)
    response = client.list_images(req)
    images = getattr(response, "images", None) or []
    if not images:
        raise RuntimeError("未在当前 Region 找到 Ubuntu 64-bit 公共镜像。")

    def score(image: Any) -> tuple[int, str]:
        text = f"{getattr(image, 'name', '')} {getattr(image, 'os_version', '')}".lower()
        if "22.04" in text:
            rank = 0
        elif "20.04" in text:
            rank = 1
        elif "ubuntu" in text:
            rank = 2
        else:
            rank = 9
        return (rank, getattr(image, "created_at", "") or "")

    chosen = sorted(images, key=score)[0]
    image_id = getattr(chosen, "id")
    config["image_name"] = getattr(chosen, "name", image_id)
    log(f"已选择 Ubuntu 镜像: {getattr(chosen, 'name', image_id)} ({image_id})")
    return image_id


def prepare_defaults(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    config["flavor"] = choose_flavor(config)
    config["image_id"] = choose_image(config)
    config["swr_server"] = config.get("swr_server") or f"swr.{config['region']}.myhuaweicloud.com"
    config["swr_username"] = config.get("swr_username") or f"{config['region']}@{config['ak']}"
    config["swr_password"] = config.get("swr_password") or config["sk"]
    save_config(args.config, config)


def push_image(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    tag = f"{config['swr_server'].rstrip('/')}/{config['swr_namespace']}/{config['swr_repo']}:latest"
    config["image"] = tag
    save_config(args.config, config)

    run(["docker", "build", "-t", tag, "."], cwd=args.root)
    try:
        run(["docker", "login", config["swr_server"], "-u", config["swr_username"], "--password-stdin"], input_text=config["swr_password"])
    except SystemExit:
        log("")
        log("自动 Docker 登录 SWR 失败。部分华为云临时凭证不能直接作为 Registry 登录密码。")
        password = getpass.getpass("请粘贴 SWR 控制台提供的 Docker 登录密码/登录密钥，然后按回车重试: ")
        config["swr_password"] = password
        save_config(args.config, config)
        run(["docker", "login", config["swr_server"], "-u", config["swr_username"], "--password-stdin"], input_text=password)
    run(["docker", "push", tag], cwd=args.root)
    log(f"镜像已推送: {tag}")


def source_bundle_b64(root: str) -> str:
    root_path = Path(root).resolve()
    include_paths = [
        root_path / "Dockerfile",
        root_path / "requirements.txt",
        root_path / "app",
        root_path / "frontend",
        root_path / "ops",
    ]
    buffer = io.BytesIO()

    def tar_filter(info: tarfile.TarInfo) -> tarfile.TarInfo | None:
        parts = Path(info.name).parts
        if "__pycache__" in parts or info.name.endswith(".pyc"):
            return None
        return info

    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        for path in include_paths:
            if path.exists():
                archive.add(path, arcname=path.relative_to(root_path), filter=tar_filter)
    return base64.b64encode(buffer.getvalue()).decode("ascii")


def find_by_name(items: list[Any], name: str) -> Any | None:
    for item in items:
        if getattr(item, "name", None) == name:
            return item
    return None


def list_vpcs(client: VpcClient) -> list[Any]:
    return getattr(client.list_vpcs(ListVpcsRequest(limit=100)), "vpcs", None) or []


def list_subnets(client: VpcClient, vpc_id: str) -> list[Any]:
    return getattr(client.list_subnets(ListSubnetsRequest(limit=100, vpc_id=vpc_id)), "subnets", None) or []


def ensure_vpc(client: VpcClient, name: str) -> Any:
    vpcs = list_vpcs(client)
    existing = find_by_name(vpcs, name)
    if existing:
        log(f"Reusing VPC: {name} ({existing.id})")
        return existing

    try:
        vpc_req = CreateVpcRequest()
        vpc_req.body = CreateVpcRequestBody(vpc=CreateVpcOption(name=name, cidr="192.168.0.0/16"))
        vpc = client.create_vpc(vpc_req).vpc
        log(f"VPC created: {name} ({vpc.id})")
        return vpc
    except ClientRequestException as exc:
        message = str(exc)
        if "OverQuota" in message or "Quota exceeded" in message or "VPC.0114" in message:
            vpcs = list_vpcs(client)
            if vpcs:
                fallback = vpcs[0]
                log(f"VPC quota is full. Reusing existing VPC: {getattr(fallback, 'name', fallback.id)} ({fallback.id})")
                return fallback
        raise


def ensure_subnet(client: VpcClient, vpc_id: str, name: str) -> Any:
    subnets = list_subnets(client, vpc_id)
    existing = find_by_name(subnets, name)
    if existing:
        log(f"Reusing subnet: {name} ({existing.id})")
        return existing

    if subnets:
        fallback = subnets[0]
        log(f"Reusing existing subnet: {getattr(fallback, 'name', fallback.id)} ({fallback.id})")
        return fallback

    subnet_req = CreateSubnetRequest()
    subnet_req.body = CreateSubnetRequestBody(
        subnet=CreateSubnetOption(
            name=name,
            cidr="192.168.10.0/24",
            gateway_ip="192.168.10.1",
            vpc_id=vpc_id,
        )
    )
    subnet = client.create_subnet(subnet_req).subnet
    log(f"Subnet created: {name} ({subnet.id})")
    return subnet


def ensure_security_group(client: VpcClient, name: str) -> Any:
    response = client.neutron_list_security_groups(NeutronListSecurityGroupsRequest(name=name, limit=100))
    groups = getattr(response, "security_groups", None) or []
    existing = find_by_name(groups, name)
    if existing:
        log(f"Reusing security group: {name} ({existing.id})")
        return existing

    sg_req = NeutronCreateSecurityGroupRequest()
    sg_req.body = NeutronCreateSecurityGroupRequestBody(
        security_group=NeutronCreateSecurityGroupOption(name=name)
    )
    sg = client.neutron_create_security_group(sg_req).security_group
    log(f"Security group created: {name} ({sg.id})")
    return sg


def create_network(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    client = vpc_client(config)
    name = config["ecs_name"]
    vpc_name = f"{name}-vpc"
    subnet_name = f"{name}-subnet"
    security_group_name = f"{name}-sg"

    vpc = ensure_vpc(client, vpc_name)
    vpc_name = getattr(vpc, "name", vpc_name)
    config["vpc_name"] = vpc_name
    config["vpc_id"] = vpc.id
    log(f"VPC 已创建: {vpc.id}")

    subnet = ensure_subnet(client, vpc.id, subnet_name)
    subnet_name = getattr(subnet, "name", subnet_name)
    config["subnet_name"] = subnet_name
    config["subnet_id"] = subnet.id
    log(f"Subnet 已创建: {subnet.id}")

    sg = ensure_security_group(client, security_group_name)
    security_group_name = getattr(sg, "name", security_group_name)
    config["security_group_name"] = security_group_name
    config["security_group_id"] = sg.id
    log(f"安全组已创建: {sg.id}")

    for port in (22, 80, 8080):
        rule_req = NeutronCreateSecurityGroupRuleRequest()
        rule_req.body = NeutronCreateSecurityGroupRuleRequestBody(
            security_group_rule=NeutronCreateSecurityGroupRuleOption(
                security_group_id=sg.id,
                direction="ingress",
                protocol="tcp",
                port_range_min=port,
                port_range_max=port,
                remote_ip_prefix=f"{config['operator_ip']}/32",
            )
        )
        try:
            client.neutron_create_security_group_rule(rule_req)
            log(f"Security group rule opened: {config['operator_ip']}/32 -> TCP {port}")
        except ClientRequestException as exc:
            message = str(exc)
            if "409" in message or "Conflict" in message or "already" in message.lower() or "exist" in message.lower():
                log(f"Security group rule already exists: {config['operator_ip']}/32 -> TCP {port}")
            else:
                raise
        log(f"安全组已放通: {config['operator_ip']}/32 -> TCP {port}")

    save_config(args.config, config)


def cloud_init(config: dict[str, Any]) -> str:
    def sh_quote(value: Any) -> str:
        return "'" + str(value).replace("'", "'\"'\"'") + "'"

    def yaml_quote(value: Any) -> str:
        return json.dumps(str(value))

    env = {
        "ADMIN_USERNAME": config["admin_username"],
        "ADMIN_PASSWORD": config["admin_password"],
        "SESSION_SECRET": config["session_secret"],
        "LITELLM_MASTER_KEY": config.get("litellm_master_key", ""),
    }
    env_lines = "\n".join(f"      -e {k}={sh_quote(v)} \\" for k, v in env.items())
    retry_script = """    set -eux
    retry() {
      attempts="$1"
      delay="$2"
      shift 2
      count=1
      until "$@"; do
        code="$?"
        if [ "$count" -ge "$attempts" ]; then
          echo "Command failed after $count attempts: $*" >&2
          return "$code"
        fi
        echo "Command failed with exit $code. Retrying in ${delay}s ($count/$attempts): $*" >&2
        count=$((count + 1))
        sleep "$delay"
      done
    }
    wait_network() {
      for i in $(seq 1 60); do
        if timeout 5 bash -c ': >/dev/tcp/repo.huaweicloud.com/443' || timeout 5 bash -c ': >/dev/tcp/pypi.org/443'; then
          return 0
        fi
        echo "Waiting for outbound network/EIP binding... ($i/60)" >&2
        sleep 10
      done
      return 1
    }
    wait_network
    export DEBIAN_FRONTEND=noninteractive
    retry 12 20 apt-get update
    retry 12 20 apt-get install -y --no-install-recommends openssh-server docker.io ca-certificates curl
"""
    ssh_setup = f"""ssh_pwauth: true
disable_root: false
chpasswd:
  expire: false
  users:
    - name: root
      password: {yaml_quote(config['ecs_admin_pass'])}
      type: text
"""
    if config.get("source_bundle_b64"):
        source_bundle = "\n".join(f"    {line}" for line in config["source_bundle_b64"].splitlines())
        return f"""#cloud-config
{ssh_setup}
runcmd:
  - |
{retry_script}
    sed -i 's/^#\\?PasswordAuthentication .*/PasswordAuthentication yes/' /etc/ssh/sshd_config
    sed -i 's/^#\\?PermitRootLogin .*/PermitRootLogin yes/' /etc/ssh/sshd_config
    grep -q '^PasswordAuthentication ' /etc/ssh/sshd_config || echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config
    grep -q '^PermitRootLogin ' /etc/ssh/sshd_config || echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config
    systemctl restart ssh || systemctl restart sshd
    systemctl enable --now docker
    cat >/opt/maas-source.tgz.b64 <<'MAAS_SOURCE'
{source_bundle}
    MAAS_SOURCE
    base64 -d /opt/maas-source.tgz.b64 >/opt/maas-source.tgz
    mkdir -p /opt/maas-api-key-platform
    tar -xzf /opt/maas-source.tgz -C /opt/maas-api-key-platform
    retry 12 30 docker build -t maas-api-key-platform:latest /opt/maas-api-key-platform
    docker rm -f maas-api-key-platform || true
    docker run -d --restart unless-stopped --name maas-api-key-platform \\
      -p 80:8080 \\
{env_lines}
      -v maas-postgres:/var/lib/postgresql \\
      -v maas-redis:/var/lib/redis \\
      maas-api-key-platform:latest
"""

    return f"""#cloud-config
{ssh_setup}
runcmd:
  - |
{retry_script}
    sed -i 's/^#\\?PasswordAuthentication .*/PasswordAuthentication yes/' /etc/ssh/sshd_config
    sed -i 's/^#\\?PermitRootLogin .*/PermitRootLogin yes/' /etc/ssh/sshd_config
    grep -q '^PasswordAuthentication ' /etc/ssh/sshd_config || echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config
    grep -q '^PermitRootLogin ' /etc/ssh/sshd_config || echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config
    systemctl restart ssh || systemctl restart sshd
    systemctl enable --now docker
    retry 12 20 docker login {config['swr_server']} -u {sh_quote(config['swr_username'])} -p {sh_quote(config['swr_password'])}
    retry 12 30 docker pull {config['image']}
    docker rm -f maas-api-key-platform || true
    docker run -d --restart unless-stopped --name maas-api-key-platform \\
      -p 80:8080 \\
{env_lines}
      -v maas-postgres:/var/lib/postgresql \\
      -v maas-redis:/var/lib/redis \\
      {config['image']}
"""


def create_ecs(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    if args.root:
        config["deployment_mode"] = "remote-build"
        config["image"] = "maas-api-key-platform:latest"
        config["source_bundle_b64"] = source_bundle_b64(args.root)
        save_config(args.config, config)
    config["bandwidth_size"] = int(config.get("bandwidth_size", 300))
    client = ecs_client(config)
    user_data = base64.b64encode(cloud_init(config).encode("utf-8")).decode("ascii")

    server = PrePaidServer(
        name=config["ecs_name"],
        image_ref=config["image_id"],
        flavor_ref=config["flavor"],
        admin_pass=config["ecs_admin_pass"],
        vpcid=config["vpc_id"],
        nics=[PrePaidServerNic(subnet_id=config["subnet_id"])],
        security_groups=[PrePaidServerSecurityGroup(id=config["security_group_id"])],
        publicip=PrePaidServerPublicip(
            eip=PrePaidServerEip(
                iptype=config.get("eip_type", "5_bgp"),
                bandwidth=PrePaidServerEipBandwidth(size=int(config.get("bandwidth_size", 300)), sharetype="PER"),
            ),
            delete_on_termination=True,
        ),
        root_volume=PrePaidServerRootVolume(volumetype="SAS", size=40),
        user_data=user_data,
        count=1,
    )
    request = CreateServersRequest()
    request.body = CreateServersRequestBody(server=server)
    response = client.create_servers(request)
    server_ids = getattr(response, "server_ids", None) or []
    config["ecs_response"] = response.to_json_object() if hasattr(response, "to_json_object") else str(response)
    if server_ids:
        config["server_ids"] = server_ids
        config["ecs_id"] = server_ids[0]
        public_ip = wait_for_public_ip(client, server_ids[0])
        if public_ip:
            config["public_ip"] = public_ip
            config["web_url"] = f"http://{public_ip}/"
            config["web_url_8080"] = f"http://{public_ip}:8080/"
            log(f"ECS 公网 IP: {public_ip}")
            log(f"前端访问地址: http://{public_ip}/")
            log(f"备用端口地址: http://{public_ip}:8080/")
    save_config(args.config, config)
    log("ECS 创建请求已提交。云主机首次启动会安装 Docker、拉取镜像并设置容器开机自启动。")


def extract_public_ip(server: Any) -> str | None:
    access_ip = getattr(server, "access_i_pv4", None)
    if access_ip:
        return access_ip
    addresses = getattr(server, "addresses", None) or {}
    for entries in addresses.values():
        for item in entries or []:
            ip_type = (getattr(item, "os_ext_ip_stype", "") or "").lower()
            addr = getattr(item, "addr", None)
            if addr and ("floating" in ip_type or "public" in ip_type):
                return addr
    for entries in addresses.values():
        for item in entries or []:
            addr = getattr(item, "addr", None)
            if addr and "." in addr and not addr.startswith(("10.", "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.", "192.168.")):
                return addr
    return None


def wait_for_public_ip(client: EcsClient, server_id: str, attempts: int = 40, delay: int = 15) -> str | None:
    log("正在查询 ECS 公网 IP，通常需要 1-5 分钟。")
    for index in range(1, attempts + 1):
        try:
            response = client.show_server(ShowServerRequest(server_id=server_id))
            server = getattr(response, "server", None)
            public_ip = extract_public_ip(server) if server else None
            status = getattr(server, "status", "unknown") if server else "unknown"
            if public_ip:
                return public_ip
            log(f"等待公网 IP 绑定中... ({index}/{attempts}, ECS status: {status})")
        except Exception as exc:
            log(f"查询 ECS 详情暂未成功，继续等待: {exc}")
        time.sleep(delay)
    log("未能在等待时间内查询到公网 IP，请稍后到 ECS 控制台查看。")
    return None


def log_resource_summary(config: dict[str, Any]) -> None:
    server_ids = config.get("server_ids") or []
    ecs_id = config.get("ecs_id") or (server_ids[0] if server_ids else None)
    rows = [
        ("SWR namespace", config.get("swr_namespace"), None),
        ("SWR repository", config.get("swr_repository") or config.get("swr_repo"), None),
        ("VPC", config.get("vpc_name"), config.get("vpc_id")),
        ("Subnet", config.get("subnet_name"), config.get("subnet_id")),
        ("Security group", config.get("security_group_name"), config.get("security_group_id")),
        ("ECS", config.get("ecs_name"), ecs_id),
        ("Public IP", config.get("public_ip"), None),
        ("EIP bandwidth", f"{config.get('bandwidth_size', 300)} Mbit/s", None),
        ("Container image", config.get("image"), None),
    ]

    log("Terraform/cloud resource names:")
    for resource_type, resource_name, resource_id in rows:
        if resource_name and resource_id:
            log(f"  - {resource_type}: {resource_name} ({resource_id})")
        elif resource_name:
            log(f"  - {resource_type}: {resource_name}")


def summary(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    log("")
    log_resource_summary(config)
    log("")
    log("部署流程已完成提交。")
    log(f"镜像: {config.get('image')}")
    log(f"安全组来源 IP: {config.get('operator_ip')}/32")
    if config.get("public_ip"):
        log(f"ECS 公网 IP: {config['public_ip']}")
        log("前端 Web 页面访问链接:")
        log(f"  {config['web_url']}")
        log(f"  {config['web_url_8080']}")
    else:
        log("未能自动获取 ECS 公网 IP。请在华为云 ECS 控制台查看新实例公网 IP 后访问:")
        log("  http://<ECS公网IP>/")
        log("  http://<ECS公网IP>:8080/")
    log(f"页面管理员账号: {config.get('admin_username')}")
    log("页面管理员密码为你刚才输入的平台管理员密码。")
    log("")
    log("说明: ECS 首次启动会安装 Docker 并拉取镜像，页面可能需要再等待几分钟才可打开。")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(required=True)
    for name, func in {
        "detect-ip": detect_ip,
        "prepare-defaults": prepare_defaults,
        "push-image": push_image,
        "create-network": create_network,
        "create-ecs": create_ecs,
        "summary": summary,
    }.items():
        p = sub.add_parser(name)
        p.add_argument("--config", type=Path, required=True)
        p.add_argument("--root")
        p.set_defaults(func=func)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
