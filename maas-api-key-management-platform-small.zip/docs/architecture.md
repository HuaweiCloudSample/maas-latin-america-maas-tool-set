# MaaS API Key Management Platform 架构原理图

这套系统是一个面向多公司、多业务线的 MaaS 虚拟 API Key 管理网关。它把 Web 管理台、鉴权网关、额度管控、LiteLLM 转发、PostgreSQL、Redis 和部署自动化打包成一个可一键上云的交付单元。

> Mermaid Live Editor 使用提示：不要把整份 Markdown 或 ```mermaid 围栏一起粘贴进去。它一次只解析一个图，请复制某个代码块内部从 `flowchart`、`sequenceDiagram` 或 `erDiagram` 开始的内容。也可以直接使用 `docs/mermaid-live/` 下拆好的 `.mmd` 文件。

## 1. 总览原理图

```mermaid
flowchart LR
  %% 外部访问层
  Admin["管理员浏览器<br/>Web Console"]:::human
  AppClient["业务应用<br/>OpenAI-compatible Client"]:::human

  %% 云入口
  subgraph Cloud["Huawei Cloud ECS / Docker Runtime"]
    direction LR

    subgraph Container["maas-api-key-platform 容器<br/>Supervisor 托管多进程"]
      direction TB

      Frontend["静态前端<br/>frontend/index.html<br/>frontend/app.js<br/>frontend/styles.css"]:::frontend
      API["FastAPI 后端网关<br/>app/main.py<br/>:8080"]:::api
      LiteLLM["LiteLLM Proxy<br/>127.0.0.1:4000"]:::proxy
      PG[("PostgreSQL<br/>公司 / 上游 / 分组 / Key / 审计事件")]:::db
      Redis[("Redis<br/>日/月额度计数器<br/>TTL 自动过期")]:::cache
      Config["动态 LiteLLM 配置<br/>/app/litellm_config.yaml"]:::file

      Frontend -->|"fetch /api/*"| API
      API <-->|"CRUD / 审计"| PG
      API <-->|"quota counters"| Redis
      API -->|"生成 model_list"| Config
      Config -->|"litellm --config"| LiteLLM
      API -->|"内部 /v1/* 转发<br/>Bearer LITELLM_MASTER_KEY"| LiteLLM
    end
  end

  Upstream["上游模型服务<br/>OpenAI / MaaS / 兼容 API"]:::upstream

  Admin -->|"GET / + /api/*"| Frontend
  AppClient -->|"POST /v1/*<br/>Bearer vmaas_xxx"| API
  LiteLLM -->|"真实 provider api_key<br/>model / base_url"| Upstream

  classDef human fill:#101828,stroke:#7dd3fc,color:#fff,stroke-width:2px;
  classDef frontend fill:#0f766e,stroke:#99f6e4,color:#fff,stroke-width:2px;
  classDef api fill:#7c2d12,stroke:#fdba74,color:#fff,stroke-width:2px;
  classDef proxy fill:#581c87,stroke:#d8b4fe,color:#fff,stroke-width:2px;
  classDef db fill:#1e3a8a,stroke:#93c5fd,color:#fff,stroke-width:2px;
  classDef cache fill:#991b1b,stroke:#fca5a5,color:#fff,stroke-width:2px;
  classDef file fill:#3f3f46,stroke:#d4d4d8,color:#fff,stroke-width:2px;
  classDef upstream fill:#14532d,stroke:#86efac,color:#fff,stroke-width:2px;
```

## 2. 核心请求链路

```mermaid
sequenceDiagram
  autonumber
  participant C as 业务应用
  participant A as FastAPI 网关<br/>/v1/{path}
  participant P as PostgreSQL
  participant R as Redis
  participant L as LiteLLM Proxy
  participant U as 上游模型 API

  C->>A: OpenAI-compatible 请求<br/>Authorization: Bearer vmaas_xxx
  A->>P: 查询 virtual_keys + provider + group
  P-->>A: Key 状态、上游模型、分组额度
  A->>R: 读取日/月 key 与 group 使用量
  R-->>A: 当前计数器
  A->>A: 校验 Key 是否启用<br/>校验 key/group 输入输出额度
  A->>A: 重写 body.model 为 provider-{id}-{model}
  A->>L: /v1/{path}<br/>Authorization: LiteLLM master key
  L->>U: 使用真实 provider api_key 转发
  U-->>L: 模型响应 + usage
  L-->>A: 返回响应
  A->>A: 提取 usage<br/>没有 usage 时按请求体估算
  A->>R: incrby 日/月计数器并设置 TTL
  A->>P: 更新 virtual_keys 累计用量<br/>写入 usage_events 审计
  A-->>C: 原样返回模型响应
```

## 3. 管理配置链路

```mermaid
flowchart TD
  Login["管理员登录<br/>/api/login"]:::step
  Session["本地保存 adminSession<br/>Bearer session_token"]:::step
  Company["公司<br/>companies"]:::data
  Provider["上游模型<br/>providers<br/>base_url / model / api_key"]:::data
  Group["Key 分组<br/>key_groups<br/>日/月输入输出额度"]:::data
  VKey["虚拟 Key<br/>virtual_keys<br/>vmaas_xxx / 启停 / 自定义额度"]:::data
  Sync["sync_litellm_config()"]:::action
  Config["litellm_config.yaml<br/>model_list"]:::file
  Restart["supervisorctl restart litellm"]:::action

  Login --> Session
  Session --> Company
  Session --> Provider
  Session --> Group
  Session --> VKey
  Provider -->|"新增/删除触发"| Sync
  Sync --> Config
  Config --> Restart

  classDef step fill:#111827,stroke:#67e8f9,color:#fff,stroke-width:2px;
  classDef data fill:#1d4ed8,stroke:#bfdbfe,color:#fff,stroke-width:2px;
  classDef action fill:#9a3412,stroke:#fed7aa,color:#fff,stroke-width:2px;
  classDef file fill:#52525b,stroke:#e4e4e7,color:#fff,stroke-width:2px;
```

## 4. 一键部署链路

```mermaid
flowchart LR
  Start["Start-Deploy.cmd<br/>Windows 双击入口"]:::local
  PS["deploy/Start-Deploy.ps1<br/>交互采集参数"]:::local
  Py["deploy/deploy.py<br/>华为云 SDK 编排"]:::local
  Docker["Docker build<br/>生成平台镜像"]:::build
  SWR["Huawei Cloud SWR<br/>镜像组织 / 仓库"]:::cloud
  VPC["VPC / Subnet<br/>隔离网络"]:::cloud
  SG["Security Group<br/>仅放通 operator_ip/32<br/>22 / 80 / 8080"]:::cloud
  ECS["ECS<br/>Ubuntu + cloud-init"]:::cloud
  Run["docker run<br/>-p 80:8080<br/>挂载 PG/Redis volume"]:::runtime

  Start --> PS --> Py
  Py -->|"detect-ip"| SG
  Py -->|"prepare-defaults"| Docker
  Docker -->|"push-image"| SWR
  Py -->|"create-network"| VPC --> SG
  Py -->|"create-ecs"| ECS
  SWR -->|"docker pull"| ECS
  ECS --> Run

  classDef local fill:#0f172a,stroke:#38bdf8,color:#fff,stroke-width:2px;
  classDef build fill:#713f12,stroke:#fde68a,color:#fff,stroke-width:2px;
  classDef cloud fill:#064e3b,stroke:#6ee7b7,color:#fff,stroke-width:2px;
  classDef runtime fill:#7f1d1d,stroke:#fca5a5,color:#fff,stroke-width:2px;
```

## 5. 数据模型关系

```mermaid
erDiagram
  companies ||--o{ providers : owns
  companies ||--o{ key_groups : owns
  key_groups ||--o{ virtual_keys : contains
  providers ||--o{ virtual_keys : routes_to
  virtual_keys ||--o{ usage_events : records
  key_groups ||--o{ usage_events : aggregates
  providers ||--o{ usage_events : audits

  companies {
    serial id PK
    text name
    timestamptz created_at
  }

  providers {
    serial id PK
    integer company_id FK
    text name
    text base_url
    text model
    text api_key
  }

  key_groups {
    serial id PK
    integer company_id FK
    text name
    bigint daily_input_limit
    bigint daily_output_limit
    bigint monthly_input_limit
    bigint monthly_output_limit
  }

  virtual_keys {
    serial id PK
    text name
    text token
    integer group_id FK
    integer provider_id FK
    bigint used_input
    bigint used_output
    boolean enabled
  }

  usage_events {
    bigserial id PK
    integer virtual_key_id FK
    integer group_id FK
    integer provider_id FK
    text path
    bigint input_tokens
    bigint output_tokens
    text source
    integer status_code
  }
```

## 6. 组件作用速览

| 组件 | 代码/配置位置 | 作用 |
| --- | --- | --- |
| 静态 Web 管理台 | `frontend/` | 提供登录、公司、上游模型、分组、虚拟 Key、额度和启停管理界面。 |
| FastAPI 后端 | `app/main.py` | 系统中枢。负责管理 API、管理员鉴权、虚拟 Key 鉴权、额度校验、请求转发、用量提取和审计落库。 |
| PostgreSQL | Docker 镜像内置服务 | 保存长期元数据：公司、上游模型、Key 分组、虚拟 Key、累计用量和 usage events。 |
| Redis | Docker 镜像内置服务 | 保存日/月实时额度计数器，使用 TTL 自动跨周期过期。 |
| LiteLLM Proxy | `ops/litellm_config.yaml` + Supervisor | 负责真正的 OpenAI-compatible 上游转发，屏蔽不同 provider 的 base_url、model 和 api_key。 |
| 动态配置同步 | `sync_litellm_config()` | 当上游模型新增/删除时，重写 LiteLLM `model_list` 并重启 LiteLLM。 |
| Supervisor | `ops/supervisord.conf` | 在一个容器内统一拉起 PostgreSQL、Redis、FastAPI 和 LiteLLM。 |
| 容器入口 | `ops/entrypoint.sh` | 初始化 PostgreSQL 数据目录、调整本地认证、启动 Supervisor。 |
| Docker 镜像 | `Dockerfile` | 把运行时依赖、后端、前端、数据库、缓存和代理打包成单镜像。 |
| 一键部署脚本 | `Start-Deploy.cmd`、`deploy/Start-Deploy.ps1`、`deploy/deploy.py` | 采集华为云参数，创建/复用云资源，构建推送镜像，创建 ECS 并通过 cloud-init 运行容器。 |

## 7. 设计要点

- 管理面和业务面共用 FastAPI，但路径分离：`/api/*` 是管理接口，`/v1/*` 是 OpenAI-compatible 业务代理。
- 客户端永远只拿到 `vmaas_` 虚拟 Key；真实 provider API Key 只保存在数据库和 LiteLLM 配置中。
- 额度有两层：虚拟 Key 层和分组层；两层都会校验日/月输入输出 token。
- Token 用量优先使用上游返回的 `usage`，没有时按请求体长度估算，避免审计空洞。
- Postgres 管事实与审计，Redis 管高频限额计数；这是典型的“强持久 + 快计数”组合。
- 部署形态偏向交付简单：单镜像、单 ECS、单容器多进程，适合快速部署和小规模内部门户。
