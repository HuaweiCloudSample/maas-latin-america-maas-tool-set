const i18n = {
  zh: {
    subtitle: "多公司共享的虚拟 API Key、分组额度和用量管理",
    adminUser: "管理员账号",
    adminPassword: "管理员密码",
    login: "登录",
    loginSuccess: "登录成功",
    company: "公司",
    companyName: "公司名称",
    addCompany: "添加公司",
    provider: "上游模型",
    providerShort: "上游",
    providerName: "上游名称，例如 OpenAI 主账号",
    baseUrl: "Base URL，例如 https://api.openai.com",
    model: "模型，例如 gpt-4o-mini",
    providerApiKey: "上游 API Key",
    addProvider: "添加上游",
    keyGroup: "Key 分组",
    group: "分组",
    groupName: "分组名称，例如 公司A-生产组",
    dailyInputM: "日输入百万token，留空不限",
    dailyOutputM: "日输出百万token，留空不限",
    monthlyInputM: "月输入百万token，留空不限",
    monthlyOutputM: "月输出百万token，留空不限",
    addGroup: "添加分组",
    virtualKey: "虚拟 Key",
    businessName: "业务名称，例如 app-prod",
    ownerCode: "责任人工号，例如 10012345",
    owner: "责任人",
    dailyInputCustom: "日输入自定义",
    dailyOutputCustom: "日输出自定义",
    monthlyInputCustom: "月输入自定义",
    monthlyOutputCustom: "月输出自定义",
    generateKey: "生成虚拟 Key",
    keyList: "虚拟 Key 列表",
    refresh: "刷新",
    name: "名称",
    usage: "累计输入/输出",
    status: "状态",
    groupList: "分组列表",
    keyCount: "Key数",
    dailyInOut: "日输入/输出",
    monthlyInOut: "月输入/输出",
    providerCompany: "上游与公司",
    type: "类型",
    details: "详情",
    unlimited: "不限",
    shared: "均分",
    daily: "日",
    monthly: "月",
    enabled: "启用",
    disabled: "停用",
    copy: "复制",
    copied: "已复制",
    disable: "停用",
    enable: "启用",
    delete: "删除",
    bindOwner: "绑定责任人",
    ownerPrompt: "请输入责任人工号，留空表示解绑",
    editQuota: "修改限额",
    usageStats: "用量统计",
    groupUsageStats: "分组 token 消费总量",
    topKeyUsageStats: "Top5 虚拟 Key 用量",
    totalUsage: "总消耗",
    editQuotaPrompt: "请输入{label}限额（单位：百万 token，留空表示按分组均分）",
    customOverGroup: "{label}自定义额度不能超过分组额度：{limit}",
    customTotalOverGroup: "{label}自定义额度总和不能超过分组额度：当前已分配 {current}，本次新增 {next}，分组额度 {limit}",
    confirmFirstTokenGroupLimit: "未输入限额，是否使用该分组的总额度来设置该虚拟key额度",
    confirmDefaultTokenLimit: "token限额未输入，系统默认以当前分组下已存在的虚拟apikey的平均值来设置，如果用户确认，那就默认以当前分组下已存在的虚拟apikey的平均值来设置，如果平均值超过该分组累计剩余额度，则以剩余额度设置虚拟apikey的限额",
  },
  en: {
    subtitle: "Shared virtual API keys, group quotas, and usage management",
    adminUser: "Admin username",
    adminPassword: "Admin password",
    login: "Log in",
    loginSuccess: "Login successful",
    company: "Company",
    companyName: "Company name",
    addCompany: "Add company",
    provider: "Upstream model",
    providerShort: "Provider",
    providerName: "Provider name, e.g. OpenAI main account",
    baseUrl: "Base URL, e.g. https://api.openai.com",
    model: "Model, e.g. gpt-4o-mini",
    providerApiKey: "Provider API key",
    addProvider: "Add provider",
    keyGroup: "Key group",
    group: "Group",
    groupName: "Group name, e.g. CompanyA production",
    dailyInputM: "Daily input M tokens, blank for unlimited",
    dailyOutputM: "Daily output M tokens, blank for unlimited",
    monthlyInputM: "Monthly input M tokens, blank for unlimited",
    monthlyOutputM: "Monthly output M tokens, blank for unlimited",
    addGroup: "Add group",
    virtualKey: "Virtual key",
    businessName: "Business name, e.g. app-prod",
    ownerCode: "Owner employee ID, e.g. 10012345",
    owner: "Owner",
    dailyInputCustom: "Custom daily input",
    dailyOutputCustom: "Custom daily output",
    monthlyInputCustom: "Custom monthly input",
    monthlyOutputCustom: "Custom monthly output",
    generateKey: "Generate virtual key",
    keyList: "Virtual key list",
    refresh: "Refresh",
    name: "Name",
    usage: "Used input/output",
    status: "Status",
    groupList: "Group list",
    keyCount: "Keys",
    dailyInOut: "Daily input/output",
    monthlyInOut: "Monthly input/output",
    providerCompany: "Providers and companies",
    type: "Type",
    details: "Details",
    unlimited: "Unlimited",
    shared: "shared",
    daily: "Daily",
    monthly: "Monthly",
    enabled: "Enabled",
    disabled: "Disabled",
    copy: "Copy",
    copied: "Copied",
    disable: "Disable",
    enable: "Enable",
    delete: "Delete",
    bindOwner: "Bind owner",
    ownerPrompt: "Enter owner employee ID. Leave blank to unbind.",
    editQuota: "Edit quota",
    usageStats: "Usage stats",
    groupUsageStats: "Group token usage totals",
    topKeyUsageStats: "Top 5 virtual key usage",
    totalUsage: "Total",
    editQuotaPrompt: "Enter {label} quota in M tokens. Leave blank to share group quota.",
    customOverGroup: "{label} custom quota cannot exceed the group quota: {limit}",
    customTotalOverGroup: "{label} custom quota total cannot exceed the group quota: allocated {current}, new {next}, group quota {limit}",
    confirmFirstTokenGroupLimit: "Quota is empty. Use this group's total quota as the virtual key quota?",
    confirmDefaultTokenLimit: "Token quota is empty. The system will use the average quota of existing virtual API keys in the current group. If the average is greater than the group's remaining quota, the remaining quota will be used instead.",
  },
};

const state = {
  token: localStorage.getItem("adminSession") || "",
  lang: localStorage.getItem("uiLang") || "zh",
  companies: [],
  providers: [],
  groups: [],
  keys: [],
  usageSummary: { groups: [], top_keys: [] },
};

const $ = (selector) => document.querySelector(selector);
const t = (key) => (i18n[state.lang] && i18n[state.lang][key]) || i18n.zh[key] || key;
const format = (template, values) => Object.entries(values).reduce((text, [key, value]) => text.replace(`{${key}}`, value), template);
const tokenM = (value) => value === null || value === undefined ? t("unlimited") : `${(Number(value) / 1000000).toFixed(2)}M`;
const keyLimitM = (value, custom) => `${tokenM(value)}${custom ? "" : ` ${t("shared")}`}`;
const limitFields = [
  ["daily_input_m", "daily_input_limit", "daily_input_limit_custom", "dailyInOut"],
  ["daily_output_m", "daily_output_limit", "daily_output_limit_custom", "dailyInOut"],
  ["monthly_input_m", "monthly_input_limit", "monthly_input_limit_custom", "monthlyInOut"],
  ["monthly_output_m", "monthly_output_limit", "monthly_output_limit_custom", "monthlyInOut"],
];
const quotaLabelKeys = {
  daily_input_m: "dailyInputCustom",
  daily_output_m: "dailyOutputCustom",
  monthly_input_m: "monthlyInputCustom",
  monthly_output_m: "monthlyOutputCustom",
};

function headers() {
  return {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${state.token}`,
  };
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { ...headers(), ...(options.headers || {}) },
  });
  if (!response.ok) throw new Error(await response.text() || response.statusText);
  return response.json();
}

function formData(form) {
  const raw = Object.fromEntries(new FormData(form).entries());
  for (const [key, value] of Object.entries(raw)) {
    if (value === "") raw[key] = null;
    if (key.endsWith("_id")) raw[key] = Number(value);
    if (key.endsWith("_m") && value !== null) raw[key] = Number(value);
  }
  return raw;
}

function applyLanguage() {
  document.documentElement.lang = state.lang === "zh" ? "zh-CN" : "en";
  document.querySelectorAll("[data-i18n]").forEach((node) => {
    node.textContent = t(node.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((node) => {
    node.placeholder = t(node.dataset.i18nPlaceholder);
  });
  document.querySelectorAll("[data-lang]").forEach((button) => {
    button.classList.toggle("active", button.dataset.lang === state.lang);
  });
}

function setLanguage(lang) {
  state.lang = lang;
  localStorage.setItem("uiLang", lang);
  applyLanguage();
  renderTables();
}

function fillSelect(selector, rows, render) {
  const select = $(selector);
  select.innerHTML = rows.map((row) => `<option value="${row.id}">${render(row)}</option>`).join("");
}

function tokenValue(valueM) {
  return valueM === null || valueM === undefined ? null : Math.round(Number(valueM) * 1000000);
}

function errorMessage(error) {
  try {
    const payload = JSON.parse(error.message);
    return payload.detail || error.message;
  } catch {
    return error.message;
  }
}

function validateVirtualKeyLimits(payload, excludeKeyId = null) {
  const group = state.groups.find((item) => item.id === payload.group_id);
  if (!group) return true;

  for (const [inputKey, limitKey, customKey, labelKey] of limitFields) {
    const custom = tokenValue(payload[inputKey]);
    if (custom === null) continue;

    const groupLimit = group[limitKey];
    if (groupLimit === null || groupLimit === undefined) continue;

    const limit = Number(groupLimit);
    const label = t(labelKey);
    if (custom > limit) {
      alert(format(t("customOverGroup"), { label, limit: tokenM(limit) }));
      return false;
    }

    const currentCustomTotal = state.keys
      .filter((key) => key.id !== excludeKeyId && key.group_id === payload.group_id && key[customKey])
      .reduce((sum, key) => sum + Number(key[limitKey] || 0), 0);

    if (currentCustomTotal + custom > limit) {
      alert(format(t("customTotalOverGroup"), {
        label,
        current: tokenM(currentCustomTotal),
        next: tokenM(custom),
        limit: tokenM(limit),
      }));
      return false;
    }
  }

  return true;
}

function groupKeys(groupId) {
  return state.keys.filter((key) => key.group_id === groupId);
}

function allocatedGroupLimit(groupId, limitKey) {
  return groupKeys(groupId).reduce((sum, key) => sum + Number(key[limitKey] || 0), 0);
}

function averageGroupLimit(groupId, limitKey) {
  const limits = groupKeys(groupId)
    .map((key) => key[limitKey])
    .filter((limit) => limit !== null && limit !== undefined);
  if (limits.length === 0) return null;
  const total = limits.reduce((sum, limit) => sum + Number(limit), 0);
  return Math.floor(total / limits.length);
}

function defaultTokenLimit(group, limitKey) {
  const average = averageGroupLimit(group.id, limitKey);
  if (average === null) return null;
  if (group[limitKey] === null || group[limitKey] === undefined) return average;

  const remaining = Math.max(Number(group[limitKey]) - allocatedGroupLimit(group.id, limitKey), 0);
  return Math.min(average, remaining);
}

function applyDefaultVirtualKeyLimits(payload) {
  const emptyLimitFields = limitFields.filter(([inputKey]) => payload[inputKey] === null || payload[inputKey] === undefined);
  if (emptyLimitFields.length === 0) return true;

  const group = state.groups.find((item) => item.id === payload.group_id);
  if (!group) return true;

  const existingKeys = groupKeys(payload.group_id);
  if (existingKeys.length === 0) {
    if (!confirm(t("confirmFirstTokenGroupLimit"))) return false;
    for (const [inputKey, limitKey] of emptyLimitFields) {
      const limit = group[limitKey];
      if (limit !== null && limit !== undefined) payload[inputKey] = Number(limit) / 1000000;
    }
    return true;
  }

  if (!confirm(t("confirmDefaultTokenLimit"))) return false;

  for (const [inputKey, limitKey] of emptyLimitFields) {
    const limit = defaultTokenLimit(group, limitKey);
    if (limit !== null) payload[inputKey] = limit / 1000000;
  }

  return true;
}

async function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.left = "-9999px";
  document.body.appendChild(textarea);
  textarea.select();
  textarea.setSelectionRange(0, textarea.value.length);
  const copied = document.execCommand("copy");
  textarea.remove();
  if (!copied) throw new Error("copy failed");
}

async function loadHealth() {
  const health = await fetch("/api/health").then((r) => r.json());
  $("#apiStatus").textContent = health.api;
  $("#pgStatus").textContent = health.postgres;
  $("#redisStatus").textContent = health.redis;
  $("#litellmStatus").textContent = health.litellm;
}

function renderCompanies() {
  $("#companies").innerHTML = state.companies.map((c) => `
    <tr>
      <td>${t("company")}</td>
      <td>${c.name}</td>
      <td>#${c.id}</td>
      <td class="actions"><button data-delete-company="${c.id}">${t("delete")}</button></td>
    </tr>
  `).join("");
}

async function loadCompanies() {
  state.companies = await api("/api/companies");
  fillSelect("#providerForm select[name=company_id]", state.companies, (c) => c.name);
  fillSelect("#groupForm select[name=company_id]", state.companies, (c) => c.name);
  renderCompanies();
}

function renderProviders() {
  $("#providers").innerHTML = state.providers.map((p) => `
    <tr>
      <td>${t("providerShort")}</td>
      <td>${p.company_name} / ${p.name}</td>
      <td>${p.model}<br><span class="subtle">${p.base_url}</span></td>
      <td class="actions"><button data-delete-provider="${p.id}">${t("delete")}</button></td>
    </tr>
  `).join("");
}

async function loadProviders() {
  state.providers = await api("/api/providers");
  fillSelect("#keyForm select[name=provider_id]", state.providers, (p) => `${p.company_name} / ${p.name} / ${p.model}`);
  renderProviders();
}

function renderGroups() {
  $("#groups").innerHTML = state.groups.map((g) => `
    <tr>
      <td>${g.company_name}</td>
      <td>${g.name}</td>
      <td>${g.key_count}</td>
      <td>${tokenM(g.daily_input_limit)} / ${tokenM(g.daily_output_limit)}</td>
      <td>${tokenM(g.monthly_input_limit)} / ${tokenM(g.monthly_output_limit)}</td>
      <td class="actions"><button data-delete-group="${g.id}">${t("delete")}</button></td>
    </tr>
  `).join("");
}

function renderUsageSummary() {
  $("#groupUsage").innerHTML = state.usageSummary.groups.map((g) => `
    <tr>
      <td>${g.company_name}</td>
      <td>${g.group_name}</td>
      <td>${tokenM(g.total_tokens)}</td>
      <td>${tokenM(g.used_input)} / ${tokenM(g.used_output)}</td>
    </tr>
  `).join("");

  $("#topKeys").innerHTML = state.usageSummary.top_keys.map((k, index) => `
    <tr>
      <td>#${index + 1}</td>
      <td>${k.company_name} / ${k.group_name}</td>
      <td>${k.name}<br><span class="subtle">${t("owner")}: ${k.owner_code || "-"}</span></td>
      <td>${tokenM(k.total_tokens)}</td>
      <td>${tokenM(k.used_input)} / ${tokenM(k.used_output)}</td>
    </tr>
  `).join("");
}

async function loadGroups() {
  state.groups = await api("/api/groups");
  fillSelect("#keyForm select[name=group_id]", state.groups, (g) => `${g.company_name} / ${g.name}`);
  renderGroups();
}

function renderKeys() {
  $("#keys").innerHTML = state.keys.map((k) => `
    <tr>
      <td>${k.company_name}</td>
      <td>${k.group_name}</td>
      <td>${k.name}<br><span class="subtle">${t("owner")}: ${k.owner_code || "-"}</span></td>
      <td>${k.provider_name}<br><span class="subtle">${k.model}</span></td>
      <td class="token" title="${k.token}">${k.token}</td>
      <td>
        ${tokenM(k.used_input)} / ${tokenM(k.used_output)}
        <br><span class="subtle">${t("daily")} ${keyLimitM(k.daily_input_limit, k.daily_input_limit_custom)} / ${keyLimitM(k.daily_output_limit, k.daily_output_limit_custom)}</span>
        <br><span class="subtle">${t("monthly")} ${keyLimitM(k.monthly_input_limit, k.monthly_input_limit_custom)} / ${keyLimitM(k.monthly_output_limit, k.monthly_output_limit_custom)}</span>
      </td>
      <td>${k.enabled ? t("enabled") : t("disabled")}</td>
      <td class="actions">
        <button data-copy="${k.token}">${t("copy")}</button>
        <button data-edit-owner="${k.id}">${t("bindOwner")}</button>
        <button data-edit-quota="${k.id}">${t("editQuota")}</button>
        <button data-toggle="${k.id}">${k.enabled ? t("disable") : t("enable")}</button>
        <button data-delete-key="${k.id}">${t("delete")}</button>
      </td>
    </tr>
  `).join("");
}

async function loadKeys() {
  state.keys = await api("/api/virtual-keys");
  renderKeys();
}

async function loadUsageSummary() {
  state.usageSummary = await api("/api/usage/summary");
  renderUsageSummary();
}

function renderTables() {
  renderCompanies();
  renderProviders();
  renderGroups();
  renderKeys();
  renderUsageSummary();
}

async function refresh() {
  await loadHealth();
  if (!state.token) return;
  await loadCompanies();
  await loadProviders();
  await loadGroups();
  await loadKeys();
  await loadUsageSummary();
}

function keyLimitInputValue(key, limitKey, customKey) {
  return key[customKey] ? String(Number(key[limitKey] || 0) / 1000000) : "";
}

async function editKeyQuota(keyId) {
  const key = state.keys.find((item) => item.id === keyId);
  if (!key) return;

  const payload = { group_id: key.group_id };
  for (const [inputKey, limitKey, customKey, labelKey] of limitFields) {
    const label = t(quotaLabelKeys[inputKey] || labelKey);
    const value = prompt(format(t("editQuotaPrompt"), { label }), keyLimitInputValue(key, limitKey, customKey));
    if (value === null) return;
    payload[inputKey] = value.trim() === "" ? null : Number(value);
    if (payload[inputKey] !== null && Number.isNaN(payload[inputKey])) {
      alert(format(t("editQuotaPrompt"), { label }));
      return;
    }
  }

  if (!validateVirtualKeyLimits(payload, keyId)) return;
  await api(`/api/virtual-keys/${keyId}/limits`, { method: "PATCH", body: JSON.stringify(payload) });
}

async function editKeyOwner(keyId) {
  const key = state.keys.find((item) => item.id === keyId);
  if (!key) return;
  const value = prompt(t("ownerPrompt"), key.owner_code || "");
  if (value === null) return;
  await api(`/api/virtual-keys/${keyId}/owner`, {
    method: "PATCH",
    body: JSON.stringify({ owner_code: value.trim() || null }),
  });
}

$("#loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = formData(event.currentTarget);
  try {
    const result = await fetch("/api/login", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload),
    }).then(async (r) => {
      if (!r.ok) throw new Error(await r.text());
      return r.json();
    });
    state.token = result.token;
    localStorage.setItem("adminSession", state.token);
    await refresh();
    alert(t("loginSuccess"));
  } catch (error) {
    alert(errorMessage(error));
  }
});

$("#refresh").addEventListener("click", refresh);

document.querySelectorAll("[data-lang]").forEach((button) => {
  button.addEventListener("click", () => setLanguage(button.dataset.lang));
});

for (const id of ["companyForm", "providerForm", "groupForm", "keyForm"]) {
  $(`#${id}`).addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const payload = formData(form);
    if (id === "keyForm" && !applyDefaultVirtualKeyLimits(payload)) return;
    if (id === "keyForm" && !validateVirtualKeyLimits(payload)) return;
    const path = {
      companyForm: "/api/companies",
      providerForm: "/api/providers",
      groupForm: "/api/groups",
      keyForm: "/api/virtual-keys",
    }[id];
    try {
      await api(path, { method: "POST", body: JSON.stringify(payload) });
      form.reset();
      await refresh();
    } catch (error) {
      alert(errorMessage(error));
    }
  });
}

document.body.addEventListener("click", async (event) => {
  const target = event.target;
  if (!target.matches("button")) return;
  if (target.dataset.copy) {
    await copyText(target.dataset.copy);
    const originalText = target.textContent;
    target.textContent = t("copied");
    setTimeout(() => {
      target.textContent = originalText;
    }, 1200);
    return;
  }
  if (target.dataset.editOwner) await editKeyOwner(Number(target.dataset.editOwner));
  if (target.dataset.editQuota) await editKeyQuota(Number(target.dataset.editQuota));
  if (target.dataset.toggle) await api(`/api/virtual-keys/${target.dataset.toggle}/toggle`, { method: "PATCH" });
  if (target.dataset.deleteKey) await api(`/api/virtual-keys/${target.dataset.deleteKey}`, { method: "DELETE" });
  if (target.dataset.deleteGroup) await api(`/api/groups/${target.dataset.deleteGroup}`, { method: "DELETE" });
  if (target.dataset.deleteProvider) await api(`/api/providers/${target.dataset.deleteProvider}`, { method: "DELETE" });
  if (target.dataset.deleteCompany) await api(`/api/companies/${target.dataset.deleteCompany}`, { method: "DELETE" });
  await refresh();
});

applyLanguage();
refresh().catch(console.error);
