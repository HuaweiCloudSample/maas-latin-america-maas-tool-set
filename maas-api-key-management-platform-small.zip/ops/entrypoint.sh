#!/usr/bin/env bash
set -euo pipefail

mkdir -p /run/postgresql /var/log/supervisor /var/lib/redis
chown -R postgres:postgres /run/postgresql /var/lib/postgresql
chown -R redis:redis /var/lib/redis

if [ ! -s /var/lib/postgresql/14/main/PG_VERSION ]; then
  mkdir -p /var/lib/postgresql/14/main
  chown -R postgres:postgres /var/lib/postgresql/14/main
  su postgres -c "/usr/lib/postgresql/14/bin/initdb -D /var/lib/postgresql/14/main"
fi

if [ -f /etc/postgresql/14/main/pg_hba.conf ]; then
  sed -i 's/^local\s\+all\s\+all\s\+.*/local all all trust/' /etc/postgresql/14/main/pg_hba.conf
  sed -i 's/^local\s\+all\s\+postgres\s\+.*/local all postgres trust/' /etc/postgresql/14/main/pg_hba.conf
fi

exec /usr/bin/supervisord -n -c /etc/supervisor/supervisord.conf
