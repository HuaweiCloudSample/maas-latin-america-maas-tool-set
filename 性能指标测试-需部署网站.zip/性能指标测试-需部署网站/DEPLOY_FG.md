# MaaS Latency Monitor - 华为云 FunctionGraph 部署指南

## 架构概览

```
FunctionGraph (定时触发) → 写入 OBS 数据桶 → 前端 OBS 桶 (静态网站) 读取展示
```

- **FunctionGraph 函数**: 定时执行时延测试，结果写入 OBS
- **OBS 数据桶**: 存储测试结果 JSON 文件（公开读）
- **OBS 前端桶**: 托管前端静态网站，通过 config.json 配置数据桶地址

---

## 前提条件

- 华为云账号（已开通 FunctionGraph、OBS 服务）
- 区域: la-north-2（墨西哥）
- MaaS API endpoint 和 API Key

---

## Step 1: 创建 OBS 桶

### 1a. 创建数据桶

```bash
# 使用华为云 CLI 或控制台创建
# 桶名: maas-latency-data (全局唯一，需替换为你的桶名)
# 区域: la-north-2
# 存储类别: 标准存储
# 公开访问: 读权限公开（允许匿名读取）
```

在 OBS 控制台设置桶策略为公开读：

```json
{
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": { "ID": ["*"] },
      "Action": ["GetObject"],
      "Resource": ["maas-latency-data/*"]
    }
  ]
}
```

### 1b. 创建前端桶

```bash
# 桶名: maas-latency-frontend (全局唯一)
# 区域: la-north-2
# 存储类别: 标准存储
# 静态网站托管: 开启
# 默认首页: index.html
```

---

## Step 2: 部署 FunctionGraph 函数

### 2a. 创建函数

1. 进入华为云 FunctionGraph 控制台
2. 点击「创建函数」
3. 选择:
   - 函数类型: 事件函数
   - 运行时: Node.js 18
   - 函数名: maas-latency-tester
   - 区域: la-north-2

### 2b. 上传代码

将 `functiongraph/` 目录下的文件打包为 zip 上传：

```powershell
cd functiongraph
npm install
Compress-Archive -Path index.js, obs.js, test.js, node_modules, package.json -DestinationPath ../maas-latency-tester.zip
```

然后在 FunctionGraph 控制台上传 `maas-latency-tester.zip`。

### 2c. 配置委托（Agency）— 让函数自动获取 OBS 访问权限

**无需配置 AK/SK！** 同一华为云账号下，FunctionGraph 通过委托自动获取临时凭证访问 OBS。

1. 进入 FunctionGraph 控制台 → 函数详情 → 「配置」选项卡
2. 找到「委托配置」，点击「编辑」
3. 委托名称选择: `functiongraph_trust`（FunctionGraph 默认委托）
4. 保存

然后确保该委托的代理账号拥有 OBS 桶的读写权限：
1. 进入 IAM 控制台 → 委托 → 找到 `functiongraph_trust`
2. 确认代理账号拥有 `OBS OperateAccess`（或更细粒度的自定义策略，仅允许操作 `maas-latency-data` 桶）

> **原理**: 函数执行时，FunctionGraph 运行时自动向 IAM 请求临时 AK/SK/SecurityToken，
> 并注入到环境变量 `HUAWEICLOUD_SDK_AK` / `HUAWEICLOUD_SDK_SK` / `HUAWEICLOUD_SDK_SECURITY_TOKEN`，
> obs.js 会自动使用这些临时凭证。

### 2d. 配置环境变量

在函数配置中添加以下环境变量（**无需 OBS_AK/OBS_SK**）：

| 变量名 | 说明 | 示例值 |
|--------|------|--------|
| `MAAS_API_URL` | OpenAI 兼容 API 地址 | `https://api-ap-southeast-1.modelarts-maas.com/openai/v1` |
| `MAAS_API_KEY` | API 密钥 | `your_api_key_here` |
| `MODELS` | 要测试的模型列表（逗号分隔） | `deepseek-v3,qwen2.5-72b` |
| `TEST_PROMPT` | 测试提示词 | `hello` |
| `TEST_INTERVAL_MINUTES` | 测试间隔（分钟） | `30` |
| `OBS_BUCKET_DATA` | 数据 OBS 桶名 | `maas-latency-data` |
| `OBS_REGION` | OBS 区域 | `la-north-2` |

### 2e. 配置定时触发器

1. 在函数详情页点击「触发器」选项卡
2. 点击「创建触发器」
3. 选择:
   - 触发器类型: 定时触发器 (TIMER)
   - 名称: latency-test-timer
   - 触发周期: 自定义
   - Cron 表达式: `0 */30 * * * ?`（每30分钟执行一次）

其他常用 Cron 表达式：
```
0 */15 * * * ?   # 每15分钟
0 */30 * * * ?   # 每30分钟
0 0 * * * ?      # 每小时
0 0 */2 * * ?    # 每2小时
```

### 2f. 手动触发测试

在函数详情页点击「测试」，验证函数执行成功。检查 OBS 数据桶中是否生成了：
- `latest.json`
- `models.json`
- `results/YYYY-MM-DD.json`

---

## Step 3: 部署前端

### 3a. 修改 config.json

编辑 `frontend/config.json`，填入实际的数据桶公开 URL：

```json
{
  "dataBucketUrl": "https://maas-latency-data.obs.la-north-2.myhuaweicloud.com",
  "models": ["deepseek-v3", "qwen2.5-72b"],
  "testPrompt": "hello",
  "testIntervalMinutes": 30,
  "apiEndpoint": "https://api-ap-southeast-1.modelarts-maas.com/openai/v1"
}
```

### 3b. 上传前端文件到 OBS

将 `frontend/` 目录下所有文件上传到前端 OBS 桶：

```powershell
# 使用华为云 OBS CLI 或控制台上传
# 确保文件路径对应桶内路径:
#   index.html → 根目录
#   config.json → 根目录
#   css/style.css → css/ 目录
#   js/api.js → js/ 目录
#   js/app.js → js/ 目录
#   js/charts.js → js/ 目录
#   js/realtime.js → js/ 目录
```

### 3c. 配置静态网站托管

在 OBS 控制台，前端桶设置：
- 静态网站托管: 开启
- 默认首页: `index.html`
- 默认 404 页: `index.html`（SPA 支持）

### 3d. 访问前端

前端 URL 格式: `https://maas-latency-frontend.obs-website.la-north-2.myhuaweicloud.com`

在浏览器中打开此 URL，应看到 MaaS Latency Monitor Dashboard。

---

## Step 4: 验证

1. 打开前端 URL，确认 Dashboard 正常加载
2. 确认指标卡片显示数据（非 `--`）
3. 确认 TPS/TTFT 图表有数据点
4. 确认 Model Health 表显示模型状态
5. 等待定时触发器执行后（最多30分钟），刷新页面确认数据更新

---

## OBS 数据文件说明

| 文件 | 说明 | 更新时机 |
|------|------|----------|
| `latest.json` | 最近500条结果摘要 + 图表数据 + 模型指标 | 每次测试后更新 |
| `models.json` | 各模型最新健康状态 | 每次测试后更新 |
| `results/YYYY-MM-DD.json` | 当日所有测试结果详情 | 每次测试后追加 |
| `config.json` (前端桶) | 前端配置（数据桶地址等） | 部署时手动设置 |

---

## 修改配置

### 修改测试模型列表

1. 修改 FunctionGraph 函数的环境变量 `MODELS`（逗号分隔模型名）
2. 修改前端 `config.json` 中的 `models` 字段，重新上传到前端 OBS 桶

### 修改测试间隔

1. 修改 FunctionGraph 定时触发器的 Cron 表达式
2. 修改前端 `config.json` 中的 `testIntervalMinutes`，重新上传

### 修改 MaaS API 地址/密钥

修改 FunctionGraph 函数的环境变量 `MAAS_API_URL` 和 `MAAS_API_KEY`

---

## 故障排查

### 前端显示 "No data yet" 或 "--"

- 检查 `config.json` 中 `dataBucketUrl` 是否正确
- 检查数据桶是否已生成 `latest.json`（手动触发一次函数）
- 检查数据桶公开读策略是否配置

### 前端 CORS 错误

- 确认数据桶已配置公开读权限
- OBS 公开桶默认允许跨域访问，如仍有问题，在数据桶 CORS 配置中添加前端桶域名

### FunctionGraph 执行失败

- 查看函数执行日志（FunctionGraph 控制台 → 函数详情 → 日志）
- 常见问题：环境变量未配置、委托未配置（OBS 访问被拒绝）、MaaS API 不可达
- 如看到 OBS 403 错误：检查委托 `functiongraph_trust` 是否已配置，代理账号是否有 OBS 权限

### 图表不渲染

- 检查浏览器控制台，确认 Chart.js CDN 可访问
- 如无法访问 jsdelivr CDN，需将 Chart.js 文件也上传到前端 OBS 桶并修改 index.html 引用路径

---

## 与原 Cloudflare 版本的差异

| 功能 | Cloudflare 版本 | 华为云版本 |
|------|----------------|-----------|
| 定时测试 | Cron Worker | FunctionGraph 定时触发器 |
| 数据存储 | KV | OBS JSON 文件 |
| 前端托管 | Pages | OBS 静态网站 |
| 配置管理 | KV + wrangler secret | 环境变量 + config.json |
| 手动测试 | 前端按钮触发 | 无（仅定时触发） |
| SSE 流式代理 | 支持 | 不支持 |
| 在线配置 | Config Modal | config.json 文件 |
| 前端数据获取 | 调 API | 直读 OBS JSON |
