// API layer - reads data directly from OBS public bucket
// Configuration is loaded from /config.json (same origin as frontend)

const Api = {
  dataBucketUrl: null,
  config: null,

  // Load config.json from the frontend OBS bucket (same origin)
  async loadConfig() {
    if (this.config) return this.config;
    try {
      const res = await fetch('./config.json');
      if (!res.ok) throw new Error(`Config fetch failed: ${res.status}`);
      this.config = await res.json();
      this.dataBucketUrl = this.config.dataBucketUrl.replace(/\/$/, '');
    } catch (err) {
      console.error('Failed to load config.json:', err);
      throw err;
    }
    return this.config;
  },

  // Fetch latest.json from data OBS bucket - contains all stats, chart data, model metrics
  async getStats() {
    await this.loadConfig();
    const res = await fetch(`${this.dataBucketUrl}/latest.json`);
    if (!res.ok) throw new Error(`Stats fetch failed: ${res.status}`);
    return res.json();
  },

  // Fetch models.json from data OBS bucket - model health status
  async getModels() {
    await this.loadConfig();
    const res = await fetch(`${this.dataBucketUrl}/models.json`);
    if (!res.ok) throw new Error(`Models fetch failed: ${res.status}`);
    return res.json();
  }
};
