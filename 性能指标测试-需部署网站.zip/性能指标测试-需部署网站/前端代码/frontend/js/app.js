(function() {
  let refreshInterval = null;

  // ===== Initialize =====
  async function init() {
    Charts.init();
    Realtime.init();
    setupChartRangeSelectors();

    try {
      const config = await Api.loadConfig();
      Realtime.log('Config loaded from /config.json', 'success');

      const badge = document.getElementById('auto-test-badge');
      badge.textContent = `Cron: ${config.testIntervalMinutes || 30}m`;

      // Load data from OBS
      await refreshData();
      setStatus('live', 'Connected');

      Realtime.log('Data loaded from OBS bucket', 'success');
    } catch (err) {
      setStatus('error', 'Error: ' + err.message);
      Realtime.log('Init failed: ' + err.message, 'error');
    }

    // Auto-refresh display every 60 seconds
    refreshInterval = setInterval(refreshData, 60000);
  }

  // ===== Data Refresh =====
  async function refreshData() {
    try {
      const [stats, modelsData] = await Promise.all([
        Api.getStats().catch(() => null),
        Api.getModels().catch(() => null)
      ]);

      if (stats) {
        updateCards(stats);
        Charts.update(stats);
      }

      if (modelsData) {
        updateModelHealth(modelsData);
      }

      setStatus('live', 'Connected');
      Realtime.log('Data refreshed', 'info');
    } catch (err) {
      setStatus('error', 'Refresh failed');
      Realtime.log('Refresh error: ' + err.message, 'error');
    }
  }

  // ===== Update Summary Cards =====
  function updateCards(stats) {
    const container = document.getElementById('metric-cards-container');
    const modelMetrics = stats.modelMetrics || {};
    const models = Object.keys(modelMetrics);

    if (models.length === 0) {
      container.innerHTML = '<div class="model-metric-group"><div class="model-metric-row"><div class="metric-card"><div class="metric-label">No data yet</div><div class="metric-value">--</div></div></div></div>';
      return;
    }

    container.innerHTML = models.map(model => {
      const m = modelMetrics[model];
      return `<div class="model-metric-group">
        <div class="model-metric-header">${escapeHtml(model)}</div>
        <div class="model-metric-row">
          <div class="metric-card">
            <div class="metric-label">Current TPS</div>
            <div class="metric-value accent-cyan">${fmtVal(m.currentTps, 1)}</div>
            <div class="metric-unit">tokens/sec</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Avg TPS</div>
            <div class="metric-value accent-cyan">${fmtVal(m.avgTps, 1)}</div>
            <div class="metric-unit">tokens/sec</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Current TTFT</div>
            <div class="metric-value accent-orange">${fmtVal(m.currentTtft, 0)}</div>
            <div class="metric-unit">ms</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">Avg TTFT</div>
            <div class="metric-value accent-orange">${fmtVal(m.avgTtft, 0)}</div>
            <div class="metric-unit">ms</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">TPOT</div>
            <div class="metric-value accent-purple">${fmtVal(m.currentTpot, 1)}</div>
            <div class="metric-unit">ms/token</div>
          </div>
        </div>
      </div>`;
    }).join('');
  }

  function fmtVal(value, decimals) {
    return (value != null && value !== 0) ? value.toFixed(decimals) : '--';
  }

  // ===== Update Model Health Table =====
  function updateModelHealth(modelsMap) {
    // modelsMap is { modelName: { name, status, lastTest, lastLatency, tps, ttft } }
    const list = Object.values(modelsMap || {});
    const total = list.length;
    const healthy = list.filter(m => m.status === 'healthy').length;
    const failed = list.filter(m => m.status === 'failed').length;
    const pending = list.filter(m => m.status !== 'healthy' && m.status !== 'failed').length;

    document.getElementById('health-total').textContent = total;
    document.getElementById('health-healthy').textContent = healthy;
    document.getElementById('health-failed').textContent = failed;
    document.getElementById('health-pending').textContent = pending;

    const tbody = document.getElementById('model-table-body');
    if (list.length === 0) {
      tbody.innerHTML = '<tr class="empty-row"><td colspan="6">No models configured</td></tr>';
      return;
    }

    tbody.innerHTML = list.map(m => {
      const statusClass = `status-${m.status}`;
      const statusText = m.status.toUpperCase();
      const lastTest = m.lastTest ? new Date(m.lastTest).toLocaleString() : '--';
      const latency = m.lastLatency != null ? m.lastLatency.toFixed(0) + 'ms' : '--';
      const tps = m.tps != null ? m.tps.toFixed(1) : '--';
      const ttft = m.ttft != null ? m.ttft.toFixed(0) + 'ms' : '--';

      return `<tr>
        <td>${escapeHtml(m.name)}</td>
        <td><span class="status-badge ${statusClass}">${statusText}</span></td>
        <td>${lastTest}</td>
        <td>${latency}</td>
        <td>${tps}</td>
        <td>${ttft}</td>
      </tr>`;
    }).join('');
  }

  // ===== Status Indicator =====
  function setStatus(state, text) {
    const dot = document.getElementById('status-dot');
    const label = document.getElementById('status-text');
    dot.className = 'status-dot ' + state;
    label.textContent = text;
  }

  // ===== Chart Range Selectors =====
  function setupChartRangeSelectors() {
    document.getElementById('tps-range').addEventListener('change', () => {
      if (Charts._lastStats) Charts.update(Charts._lastStats);
    });
    document.getElementById('ttft-range').addEventListener('change', () => {
      if (Charts._lastStats) Charts.update(Charts._lastStats);
    });
  }

  // ===== Utility =====
  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ===== Start =====
  init();
})();
