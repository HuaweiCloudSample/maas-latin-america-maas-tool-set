const Charts = {
  tpsChart: null,
  ttftChart: null,
  colorPalette: ['#58a6ff', '#3fb950', '#d29922', '#f85149', '#bc8cff', '#79c0ff', '#ffa657', '#7ee787'],
  modelFilter: {},
  allModels: [],

  init() {
    const gridColor = '#30363d';
    const tickColor = '#8b949e';

    const commonOptions = {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 300 },
      interaction: { mode: 'index', intersect: false },
      scales: {
        x: {
          type: 'time',
          grid: { color: gridColor, lineWidth: 0.5 },
          ticks: {
            color: tickColor,
            font: { size: 10, family: 'monospace' },
            maxTicksLimit: 12
          },
          time: {
            displayFormats: { minute: 'HH:mm', hour: 'HH:mm' }
          }
        },
        y: {
          grid: { color: gridColor, lineWidth: 0.5 },
          ticks: {
            color: tickColor,
            font: { size: 10, family: 'monospace' }
          },
          beginAtZero: true
        }
      },
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#e6edf3',
            font: { size: 11 },
            usePointStyle: true,
            pointStyle: 'circle',
            padding: 16
          }
        },
        tooltip: {
          backgroundColor: '#1c2128',
          borderColor: '#30363d',
          borderWidth: 1,
          titleColor: '#e6edf3',
          bodyColor: '#8b949e',
          titleFont: { family: 'monospace', size: 11 },
          bodyFont: { family: 'monospace', size: 11 },
          callbacks: {
            title: function(items) {
              if (!items.length) return '';
              return new Date(items[0].parsed.x).toLocaleString();
            }
          }
        }
      }
    };

    this.tpsChart = new Chart(document.getElementById('tps-chart'), {
      type: 'line',
      data: { datasets: [] },
      options: {
        ...commonOptions,
        scales: {
          ...commonOptions.scales,
          y: { ...commonOptions.scales.y, title: { display: true, text: 'tokens/sec', color: tickColor, font: { size: 11 } } }
        }
      }
    });

    this.ttftChart = new Chart(document.getElementById('ttft-chart'), {
      type: 'line',
      data: { datasets: [] },
      options: {
        ...commonOptions,
        scales: {
          ...commonOptions.scales,
          y: { ...commonOptions.scales.y, title: { display: true, text: 'TTFT (ms)', color: tickColor, font: { size: 11 } } }
        }
      }
    });
  },

  // Get the time range in hours for a specific chart
  getRangeHours(chartId) {
    const select = document.getElementById(chartId === 'tps' ? 'tps-range' : 'ttft-range');
    return select ? parseInt(select.value) : 24;
  },

  // Filter data points within the given hours
  filterByRange(data, hours) {
    if (!data || !data.length) return data;
    const since = Date.now() - hours * 3600000;
    return data.filter(p => p.x >= since);
  },

  update(stats) {
    const chartData = stats.chartData || stats.byModel;
    if (!chartData) return;
    this._lastStats = stats;
    const modelNames = Object.keys(chartData);
    this.allModels = modelNames;

    for (const name of modelNames) {
      if (!(name in this.modelFilter)) {
        this.modelFilter[name] = true;
      }
    }

    this.renderFilterUI('tps-model-filter');
    this.renderFilterUI('ttft-model-filter');

    const visibleModels = modelNames.filter(name => this.modelFilter[name]);
    const tpsHours = this.getRangeHours('tps');
    const ttftHours = this.getRangeHours('ttft');

    const tpsDatasets = visibleModels.map((name) => {
      const i = this._getModelIndex(name);
      return {
        label: name,
        data: this.filterByRange(chartData[name].tps || [], tpsHours),
        borderColor: this.colorPalette[i % this.colorPalette.length],
        backgroundColor: this.colorPalette[i % this.colorPalette.length] + '20',
        borderWidth: 2,
        pointRadius: 3,
        pointHoverRadius: 5,
        fill: false,
        tension: 0.3
      };
    });

    const ttftDatasets = visibleModels.map((name) => {
      const i = this._getModelIndex(name);
      return {
        label: name,
        data: this.filterByRange(chartData[name].ttft || [], ttftHours),
        borderColor: this.colorPalette[i % this.colorPalette.length],
        backgroundColor: this.colorPalette[i % this.colorPalette.length] + '20',
        borderWidth: 2,
        pointRadius: 3,
        pointHoverRadius: 5,
        fill: false,
        tension: 0.3
      };
    });

    this.tpsChart.data.datasets = tpsDatasets;
    this.tpsChart.update();

    this.ttftChart.data.datasets = ttftDatasets;
    this.ttftChart.update();
  },

  renderFilterUI(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = this.allModels.map(name => {
      const active = this.modelFilter[name] ? 'active' : '';
      return `<label class="model-filter-label ${active}" data-model="${name}">
        <input type="checkbox" ${this.modelFilter[name] ? 'checked' : ''}> ${name}
      </label>`;
    }).join('');

    container.querySelectorAll('.model-filter-label').forEach(label => {
      label.addEventListener('click', (e) => {
        e.preventDefault();
        const model = label.dataset.model;
        this.modelFilter[model] = !this.modelFilter[model];
        label.classList.toggle('active', this.modelFilter[model]);
        label.querySelector('input').checked = this.modelFilter[model];
        if (this._lastStats) this.update(this._lastStats);
      });
    });
  },

  _modelIndexMap: {},
  _nextIdx: 0,
  _getModelIndex(model) {
    if (!(model in this._modelIndexMap)) {
      this._modelIndexMap[model] = this._nextIdx++;
    }
    return this._modelIndexMap[model];
  }
};
