// Status log - simplified version for OBS-read-only mode
// No manual test triggering, just displays refresh status

const Realtime = {
  logEl: null,

  init() {
    this.logEl = document.getElementById('realtime-log');
    document.getElementById('btn-clear-log').addEventListener('click', () => this.clearLog());
  },

  log(msg, level = 'info') {
    const el = document.createElement('div');
    el.className = `log-entry log-${level}`;
    const time = new Date().toLocaleTimeString();
    el.textContent = `[${time}] ${msg}`;
    this.logEl.prepend(el);
    while (this.logEl.children.length > 50) {
      this.logEl.removeChild(this.logEl.lastChild);
    }
  },

  clearLog() {
    this.logEl.innerHTML = '<div class="log-entry log-info">Log cleared</div>';
  }
};
